#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""问答式要素收集与写作提示（由 dialog_manager.py + smart_prompts.py 合并，功能不变）。

* ``SmartPromptSystem`` / ``create_smart_prompt_system``：15 文种的开头语、结语、结构骨架
* ``DialogManager`` / ``create_dialog_manager``：按文种逐项收集必答要素，缺什么问什么
* 命令行：``python scripts/prompts.py --hints`` 打印写作提示与结构建议；
          ``python scripts/prompts.py 通知`` 只给某个文种的写作提示；
          ``python scripts/prompts.py -o 通知.docx`` 走问答式向导直接生成。

正常出文件以 ``scripts/gongwen.py`` 为主入口；本模块用于交互式收集与写作提示。
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import sys
from typing import Any, Callable, Sequence

import gongwen

# 各文种常用开头语（依据《党政机关公文处理工作条例》第八条适用范围 + 通行写法）
OPENING_PROMPTS: dict[str, list[str]] = {
    "决议": ["XX会议听取和审议了……，会议同意这个报告，并作出如下决议：",
             "XX会议审议了……，决定如下："],
    "决定": ["为……，经研究，决定：", "根据……，现作出如下决定：",
             "XX会议审议通过，现予公布，自……起施行。"],
    "命令（令）": ["《……》已经……会议审议通过，现予公布，自……起施行。",
                   "根据……，现发布……：", "依照……，任命："],
    "公报": ["现将……予以公布：", "……（公报正文按栏目分类刊登）"],
    "公告": ["根据……有关规定，现将……公告如下：", "经……批准，现公告如下："],
    "通告": ["为……，根据……有关规定，现将有关事项通告如下：",
             "因……需要，决定对……采取……措施。现通告如下："],
    "意见": ["为……，现就……提出如下意见：", "根据……，结合我市实际，提出如下意见："],
    "通知": ["为……，现就有关事项通知如下：", "根据……，决定……。现将有关事项通知如下：",
             "经……同意，现将……印发给你们，请认真贯彻执行。"],
    "通报": ["现将……情况通报如下：", "为表彰……，经研究，决定予以通报表扬：",
             "根据……检查情况，现将有关问题通报如下："],
    "报告": ["现将……情况报告如下：", "……年，我局（委、办）……，现将有关情况报告如下：",
             "根据……要求，现将……情况报告如下："],
    "请示": ["为……，现将有关情况请示如下：", "根据……，现就……请示如下：",
             "因……需要，拟……，妥否，请批示。"],
    "批复": ["你单位《关于……的请示》（XX〔2026〕X号）收悉。经研究，现批复如下：",
             "你单位……收悉。现批复如下："],
    "议案": ["现提请审议《……（草案）》：", "根据……规定，市人民政府组织起草了《……（草案）》，现提请审议。"],
    "函": ["为……，现商请贵单位……：", "现就……函告如下：", "贵单位《关于……的函》收悉。现函复如下："],
    "纪要": ["……年……月……日，……召开……会议，听取……汇报，研究……，部署……。",
             "会议听取了……情况汇报，讨论了……，议定以下事项："],
}


# 各文种结构骨架
STRUCTURE_HINTS: dict[str, list[str]] = {
    "决议": ["标题（+subtitle 标注通过会议与日期）", "决议缘由（会议审议情况）",
             "决议事项（一、二、三……）", "执行要求与监督安排", "成文日期（不加盖印章）"],
    "决定": ["标题", "主送机关（可省略）", "决定缘由", "决定事项（一、二、三……）",
             "号召或执行要求", "发文机关署名+成文日期"],
    "命令（令）": ["发文机关标志（机关名称+令）", "令号（第X号）", "正文（公布/发布事项）",
                   "签发人职务+签名章+成文日期"],
    "公报": ["公报名称与期号", "栏目分类（政府文件/部门文件/人事任免等）",
             "各文件标题与发文字号", "印发机关和印发日期"],
    "公告": ["标题", "公告缘由与依据", "公告事项（一、二、三……）", "有关事项说明",
             "结语“特此公告。”", "发文机关署名+成文日期"],
    "通告": ["标题", "通告缘由与依据", "管理/实施措施", "执行时间与范围",
             "结语“特此通告。”", "发文机关署名+成文日期"],
    "意见": ["标题", "主送机关", "总体要求（指导思想、基本原则、目标）",
             "重点任务（一、二、三……）", "保障措施", "发文机关署名+成文日期"],
    "通知": ["标题", "主送机关", "通知缘由（依据、目的）", "通知事项（一、二、三……）",
             "工作要求与联系人", "结语“特此通知。”", "附件说明", "发文机关署名+成文日期"],
    "通报": ["标题", "主送机关", "通报缘由", "基本情况/事实经过", "处理决定或经验教训",
             "工作要求", "结语“特此通报。”", "发文机关署名+成文日期"],
    "报告": ["标题", "主送机关", "报告缘由", "主要工作（成绩、做法，一、二、三……）",
             "存在问题", "下一步安排", "结语“特此报告。”", "发文机关署名+成文日期（含签发人）"],
    "请示": ["标题（一文一事）", "主送机关（只写一个）", "请示缘由（必要性、依据）",
             "请示事项（建设内容、经费、方案）", "结语“妥否，请批示。”",
             "签发人+发文机关署名+成文日期"],
    "批复": ["标题", "主送机关", "引述来文（标题+发文字号）", "批复意见（一、二、三……）",
             "执行要求", "结语“此复。”", "发文机关署名+成文日期"],
    "议案": ["标题（关于提请审议……的议案）", "主送机关（人大或其常委会）",
             "案据（必要性、依据、起草过程）", "方案（要点或附全文草案）",
             "结语“请予审议。”", "附件（草案、说明）", "发文机关署名+成文日期"],
    "函": ["标题", "主送机关", "发函缘由", "商洽/询问/答复事项（一、二、三……）",
           "结语（请予支持为盼。/请予研究函复。/特此函告。）", "发文机关署名+成文日期"],
    "纪要": ["纪要标志", "会议概况（时间、主持、参加人员、议题）",
             "议定事项（一、二、三……，只写结论）", "出席/请假/列席名单", "印发机关和印发日期"],
}


class SmartPromptSystem:
    """按文种提供开头语、结语与结构建议。"""

    def __init__(self) -> None:
        self.openings = OPENING_PROMPTS
        self.structures = STRUCTURE_HINTS
        self.endings = gongwen.CLOSING_WORDS

    def _lookup(self, table: dict[str, list[str]], doc_type: str) -> list[str]:
        key = (doc_type or "").strip()
        if key in table:
            return list(table[key])
        for name in table:                       # 容错：命令/命令（令）等别名
            if name.startswith(key) or key.startswith(name):
                return list(table[name])
        return []

    def get_opening_prompt(self, doc_type: str) -> list[str]:
        return self._lookup(self.openings, doc_type)

    def get_ending_prompt(self, doc_type: str) -> list[str]:
        endings = self._lookup(self.endings, doc_type)
        return endings or ["（该文种一般不用结语，正文写完即止）"]

    def get_structure_hint(self, doc_type: str) -> list[str]:
        return self._lookup(self.structures, doc_type)

    def report(self, doc_type: str) -> str:
        lines = [f"# {doc_type}：写作提示", "", "## 结构骨架"]
        lines += [f"{index}. {item}" for index, item in enumerate(self.get_structure_hint(doc_type), 1)]
        lines += ["", "## 开头语（选一）"]
        lines += [f"- {item}" for item in self.get_opening_prompt(doc_type)]
        lines += ["", "## 结语"]
        lines += [f"- {item}" for item in self.get_ending_prompt(doc_type)]
        return "\n".join(lines)


def create_smart_prompt_system() -> SmartPromptSystem:
    """工厂函数（与 README 中的示例一致）。"""
    return SmartPromptSystem()


def main_prompts(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    parser = argparse.ArgumentParser(description="公文写作智能提示")
    parser.add_argument("doc_type", nargs="?", help="文种，如 通知")
    parser.add_argument("--all", action="store_true", help="打印全部文种的开头语与结语")
    args = parser.parse_args(argv)

    prompts = create_smart_prompt_system()
    if args.all or not args.doc_type:
        for doc_type in gongwen.DOC_TYPES:
            print(f"\n===== {doc_type} =====")
            print("开头语：" + " ／ ".join(prompts.get_opening_prompt(doc_type) or ["—"]))
            print("结语：" + " ／ ".join(prompts.get_ending_prompt(doc_type)))
        return 0
    if args.doc_type not in gongwen.DOC_TYPES:
        print(f"未知文种“{args.doc_type}”，可选：{'、'.join(gongwen.DOC_TYPES)}")
        return 2
    print(prompts.report(args.doc_type))
    return 0


class Step:
    """一个交互步骤。"""

    def __init__(self, key: str, question: str, *, required: bool = False,
                 default: str = "", hint: str = "", skip: Callable[[dict], bool] | None = None,
                 validate: Callable[[str, dict], str] | None = None) -> None:
        self.key = key
        self.question = question
        self.required = required
        self.default = default
        self.hint = hint
        self.skip = skip
        self.validate = validate


def _today() -> str:
    today = _dt.date.today()
    return f"{today.year}年{today.month}月{today.day}日"


def _validate_doc_number(value: str, _data: dict) -> str:
    if value and not (value.endswith("号") and "〔" in value):
        return "发文字号应形如“沈数据〔2026〕7号”（年份用六角括号、序号不编虚位）"
    return ""


def _validate_date(value: str, _data: dict) -> str:
    import re
    if value and not re.fullmatch(r"\d{4}年\d{1,2}月\d{1,2}日", value):
        return "成文日期应形如“2026年3月13日”（月、日不编虚位）"
    return ""


class DialogManager:
    """公文要素收集状态机。"""

    def __init__(self) -> None:
        self.data: dict[str, Any] = {}
        self.body_lines: list[str] = []
        self.index = 0
        self.done = False
        self.prompts = create_smart_prompt_system()

    # ------------------------------------------------------------- 步骤表
    def _steps(self) -> list[Step]:
        upward = self.data.get("doc_type") in gongwen.UPWARD_TYPES
        no_recipient = self.data.get("doc_type") in NO_RECIPIENT_TYPES
        return [
            Step("doc_type", "请选择公文类型（15 种法定文种之一）", required=True,
                 hint="、".join(gongwen.DOC_TYPES)),
            Step("issuer", "请填写发文机关全称（如：XX市数据局）", required=True),
            Step("recipient", "请填写主送机关（接收单位，末尾不需要写冒号）",
                 required=not no_recipient, skip=lambda _d: no_recipient,
                 hint="多个机关用顿号分隔，如：各区、县（市）人民政府，市政府各部门"),
            Step("subject", "请用一句话说明公文事由（如：开展2026年度安全检查工作）"),
            Step("title", "公文标题（直接回车则按“关于{事由}的{文种}”自动生成）"),
            Step("doc_number", "发文字号（如：XX数据〔2026〕7号；没有可直接回车跳过）",
                 validate=_validate_doc_number),
            Step("date", f"成文日期（直接回车用今天：{_today()}）", default=_today(),
                 validate=_validate_date),
            Step("signature", "发文机关署名（直接回车用发文机关名称）",
                 skip=lambda d: d.get("doc_type") in {"公报", "纪要"}),
            Step("signers", "签发人姓名（上行文必填；多个用顿号分隔）",
                 required=upward, skip=lambda d: d.get("doc_type") not in gongwen.UPWARD_TYPES,
                 hint="请示、报告等上行文应当标注签发人"),
            Step("secrecy", "密级和保密期限（如：秘密★1年；没有可直接回车跳过）"),
            Step("urgency", "紧急程度（特急/加急；没有可直接回车跳过）"),
            Step("body", "请逐段输入正文（每行一段，序号如“一、”“（一）”“1.”会按国标自动分层；"
                         "输入单独一行“.”结束）", required=True),
            Step("closing", "结语（直接回车则使用推荐结语）"),
            Step("attachment_note", "附件说明的附件名称（多个用分号分隔；没有可直接回车跳过）"),
            Step("copy_to", "抄送机关（没有可直接回车跳过）"),
            Step("print_org", "印发机关（直接回车用“{issuer}办公室”）"),
            Step("print_date", "印发日期（直接回车用成文日期）"),
        ]

    def _current_step(self) -> Step | None:
        steps = self._steps()
        while self.index < len(steps):
            step = steps[self.index]
            if step.skip and step.skip(self.data):
                self.index += 1
                continue
            return step
        return None

    # --------------------------------------------------------------- 接口
    def get_next_prompt(self) -> str | None:
        """返回下一个问题；全部收齐后返回 None。"""
        step = self._current_step()
        if step is None:
            self.done = True
            return None
        text = step.question
        if step.hint:
            text += f"\n（{step.hint}）"
        if step.default and "{issuer}" not in step.default:
            text += f"\n[默认：{step.default}]"
        return text

    def process_user_input(self, text: str) -> str:
        """记录一次回答；返回错误提示（空字符串表示已接受）。"""
        step = self._current_step()
        if step is None:
            self.done = True
            return ""
        value = (text or "").strip()

        if step.key == "body":
            if value == ".":
                if not self.body_lines:
                    return "正文不能为空，请至少输入一段"
                self.data["body"] = list(self.body_lines)
                self.index += 1
                return ""
            if not value:                              # 允许“空行”重试，不产生空段
                return "请输入正文段落，或输入单独一行“.”结束"
            self.body_lines.append(value)
            return ""                                  # 继续收集正文段落

        if not value and step.default:
            value = step.default.format(issuer=self.data.get("issuer", ""))
        elif not value and step.key == "print_org":
            value = f"{self.data.get('issuer', '')}办公室"
        elif not value and step.key == "signature":
            value = self.data.get("issuer", "")
        elif not value and step.key == "print_date":
            value = self.data.get("date", "")
        elif not value and step.key == "title":
            subject = self.data.get("subject", "")
            doc_type = self.data.get("doc_type", "")
            value = f"关于{subject}的{doc_type}" if subject else ""
        elif not value and step.key == "closing":
            endings = self.prompts.get_ending_prompt(self.data.get("doc_type", ""))
            value = endings[0] if endings and not endings[0].startswith("（") else ""

        if step.required and not value:
            return "该项为必填，请重新输入"
        if step.validate:
            error = step.validate(value, self.data)
            if error:
                return error

        if step.key == "recipient" and value and not value.endswith(("：", ":")):
            value += "："
        if step.key == "copy_to" and value and not value.endswith("。"):
            value += "。"
        if step.key == "doc_type" and value not in gongwen.DOC_TYPES:
            return f"“{value}”不是法定文种，请从以下选择：{'、'.join(gongwen.DOC_TYPES)}"

        if step.key == "signers":
            self.data["signers"] = [s.strip() for s in value.replace("，", "、").split("、") if s.strip()]
        elif step.key == "attachment_note":
            self.data["attachment_note"] = [s.strip() for s in value.replace("，", ";").split(";")
                                            if s.strip()]
        elif step.key == "body":
            self.data["body"] = value.splitlines() or [value]
        else:
            self.data[step.key] = value
        self.index += 1
        return ""

    def get_document_content(self) -> dict[str, Any]:
        """返回可交给 gongwen / document_generator 的要素字典。

        `closing`（结语）会并入正文末段——生成器只认 `body`，避免结语被丢掉。
        """
        content = {k: v for k, v in self.data.items() if v not in ("", [], None)}
        content.pop("subject", None)
        closing = str(content.pop("closing", "") or "").strip()
        if closing:
            body = list(content.get("body") or [])
            if not body or body[-1].strip() != closing:
                body.append(closing)
            content["body"] = body
        return content

    def summary(self) -> str:
        """生成前给用户看的要素预览。"""
        content = self.get_document_content()
        lines = ["—— 要素预览 ——"]
        for key in ("doc_type", "issuer", "recipient", "doc_number", "signers", "secrecy",
                    "urgency", "title", "date", "attachment_note", "copy_to", "print_org",
                    "print_date"):
            value = content.get(key)
            if value:
                lines.append(f"{key}: {'、'.join(value) if isinstance(value, list) else value}")
        body = content.get("body") or []
        lines.append(f"body: 共 {len(body)} 段")
        for paragraph in body:
            lines.append(f"    {paragraph[:60]}{'…' if len(paragraph) > 60 else ''}")
        return "\n".join(lines)


def create_dialog_manager() -> DialogManager:
    """工厂函数（与 README 中的示例一致）。"""
    return DialogManager()


def run_interactive(dialog: DialogManager, *, output: str | None = None,
                    save: str | None = None, silent: bool = False) -> dict[str, Any]:
    """跑完整个问答流程，返回要素字典。"""
    while True:
        prompt = dialog.get_next_prompt()
        if prompt is None:
            break
        if not silent:
            print("\n" + prompt)
        try:
            answer = input("> ")
        except EOFError:
            break
        error = dialog.process_user_input(answer)
        while error:
            if not silent:
                print(f"！{error}")
            try:
                answer = input("> ")
            except EOFError:
                return dialog.get_document_content()
            error = dialog.process_user_input(answer)

    content = dialog.get_document_content()
    if not silent:
        print("\n" + dialog.summary())
    if save:
        with open(save, "w", encoding="utf-8") as handle:
            json.dump(content, handle, ensure_ascii=False, indent=2)
        if not silent:
            print(f"\n要素已保存：{os.path.abspath(save)}")
    if output and content.get("body"):
        report = gongwen.generate(content, output)
        if not silent:
            print(f"公文已生成：{report['output']}")
            for warning in report.get("warnings") or []:
                print(f"！字体提示：{warning}")
    return content


def main_dialog(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    parser = argparse.ArgumentParser(description="公文要素对话收集器")
    parser.add_argument("-o", "--output", help="收齐后直接生成 DOCX")
    parser.add_argument("--save", help="把要素保存为 JSON")
    parser.add_argument("--answers", help="从文件逐行读取答案（替代交互输入）")
    parser.add_argument("--hints", action="store_true", help="只打印各文种的写作提示后退出")
    args = parser.parse_args(argv)

    if args.hints:
        prompts = create_smart_prompt_system()
        for doc_type in gongwen.DOC_TYPES:
            print(prompts.report(doc_type))
            print()
        return 0

    dialog = create_dialog_manager()
    if args.answers:
        # 用 utf-8-sig 兼容 Windows 记事本/PowerShell 写出的带 BOM 文件
        with open(args.answers, "r", encoding="utf-8-sig") as handle:
            lines = [line.rstrip("\n") for line in handle]
        for line in lines:
            if dialog.get_next_prompt() is None:
                break
            error = dialog.process_user_input(line)
            attempts = 0
            while error and attempts < 2:              # 校验失败：用空值兜底一次
                attempts += 1
                error = dialog.process_user_input("")
            if error:
                print(f"！跳过校验未通过的项：{error}")
                dialog.index += 1                      # 强制前进，避免死循环
        content = dialog.get_document_content()
        print(dialog.summary())
        if args.save:
            with open(args.save, "w", encoding="utf-8") as handle:
                json.dump(content, handle, ensure_ascii=False, indent=2)
            print(f"要素已保存：{os.path.abspath(args.save)}")
        if args.output and content.get("body"):
            report = gongwen.generate(content, args.output)
            print(f"公文已生成：{report['output']}")
            for warning in report.get("warnings") or []:
                print(f"！字体提示：{warning}")
        return 0

    run_interactive(dialog, output=args.output, save=args.save)
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    """命令行入口：交互/向导类参数交给对话流程，纯文种名交给写作提示。"""
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and not argv[0].startswith("-"):
        return main_prompts(argv)
    return main_dialog(argv)


if __name__ == "__main__":
    raise SystemExit(main())
