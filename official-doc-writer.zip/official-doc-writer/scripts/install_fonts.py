#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""公文字体检测与安装助手。

用法::

    python scripts/install_fonts.py                      # 检测本机字体并给出安装指引
    python scripts/install_fonts.py --copy-from C:\\Windows\\Fonts   # 把本机公文字体复制到 fonts/ 备份
    python scripts/install_fonts.py --install             # 把 fonts/ 目录里的字体装到系统（可能需要管理员）

说明：GB/T 9704—2012 只“推荐使用小标宋体字”，并未强制某一款商业字体。方正小标宋_GBK 需自行取得授权，
本脚本只能检测与安装你已有的字体文件，不能替代字体授权。
"""

from __future__ import annotations

import argparse
import os
import platform
import shutil
import sys
from typing import Sequence

_HERE = os.path.dirname(os.path.abspath(__file__))
_BUNDLE = os.path.dirname(_HERE)
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import gongwen  # noqa: E402

FONT_DIR = os.path.join(_BUNDLE, "fonts")

# 需要安装的字体：角色 -> (标准名, 用途, 常见文件名)
REQUIRED = {
    "小标宋": ("方正小标宋_GBK", "发文机关标志、标题（7.2.4、7.3.1）",
              ["FZXBSJW.TTF", "方正小标宋GBK.TTF", "方正小标宋_GBK.TTF", "FZXBSJW_GB.TTF"]),
    "仿宋": ("仿宋_GB2312", "正文、发文字号（5.2.2、7.3.3）",
             ["simfang.ttf", "SIMFANG.TTF", "FANGSONG.TTF"]),
    "黑体": ("黑体", "一级标题、密级、紧急程度（7.2.2、7.2.3、7.3.3）",
             ["simhei.ttf", "SIMHEI.TTF", "HEITI.TTF"]),
    "楷体": ("楷体_GB2312", "二级标题、签发人姓名（7.2.6、7.3.3）",
             ["simkai.ttf", "SIMKAI.TTF", "KAITI.TTF"]),
    "宋体": ("宋体", "页码（7.5）", ["simsun.ttc", "SIMSUN.TTC", "simsunb.ttf", "SONGTI.TTF"]),
}

WINDOWS_FONT_DIR = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")


def system_font_dirs() -> list[str]:
    system = platform.system()
    if system == "Windows":
        return [WINDOWS_FONT_DIR,
                os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts")]
    if system == "Darwin":
        return [os.path.expanduser("~/Library/Fonts"), "/Library/Fonts", "/System/Library/Fonts"]
    return [os.path.expanduser("~/.fonts"), os.path.expanduser("~/.local/share/fonts"),
            "/usr/share/fonts"]


def detect() -> tuple[set[str], dict[str, str]]:
    """返回 (已安装字体名集合, 各角色实际使用的字体)。"""
    installed = gongwen.detect_installed_fonts()
    resolver = gongwen.FontResolver(installed, mode="auto")
    return installed, resolver.as_dict()


def report(installed: set[str], resolved: dict[str, str]) -> bool:
    """打印检测报告，返回是否全部命中标准字体。"""
    lowered = {name.lower() for name in installed}
    print("=" * 72)
    print("公文字体检测报告")
    print("=" * 72)
    print(f"系统：{platform.system()} {platform.release()}    共检测到字体 {len(installed)} 款")
    print(f"字体目录：{' ／ '.join(d for d in system_font_dirs() if d)}")
    print(f"技能 fonts/ 目录：{FONT_DIR}")
    print("-" * 72)
    print(f"{'角色':<6}{'标准字体':<18}{'状态':<10}{'实际使用':<16}用途")
    all_standard = True
    for role, (standard, usage, _files) in REQUIRED.items():
        actual = resolved.get(gongwen.FONT_ROLE_ALIASES.get(role, role), "")
        hit = standard.lower() in lowered
        if not hit:
            all_standard = False
        print(f"{role:<6}{standard:<18}{'已安装' if hit else '缺失(回退)':<10}{actual:<16}{usage}")
    print("-" * 72)
    if all_standard:
        print("结论：标准公文字体齐备，生成结果与 GB/T 9704—2012 推荐字形一致。")
    else:
        print("结论：有标准字体未安装，生成器已自动回退到上表“实际使用”的字体，")
        print("      版式与国标一致、字形略有差异。若要完全贴合推荐字形，请取得字体授权后")
        print("      用 --install 安装，再重新生成公文。")
    return all_standard


def copy_from(source_dir: str) -> int:
    """把系统字体目录中存在的公文字体复制到 fonts/ 目录（分发/备份用）。"""
    if not os.path.isdir(source_dir):
        print(f"！目录不存在：{source_dir}")
        return 1
    os.makedirs(FONT_DIR, exist_ok=True)
    copied = 0
    for role, (_standard, _usage, filenames) in REQUIRED.items():
        for filename in filenames:
            source = os.path.join(source_dir, filename)
            if os.path.isfile(source):
                target = os.path.join(FONT_DIR, os.path.basename(filename))
                shutil.copy2(source, target)
                print(f"已复制 {role}：{os.path.basename(filename)} → fonts/")
                copied += 1
                break
        else:
            print(f"！未找到 {role} 的字体文件（{'／'.join(filenames)}），请从授权渠道获取")
    print(f"\n共复制 {copied} 个字体文件到 {FONT_DIR}")
    return 0


def install(*, assume_yes: bool = False) -> int:
    """把 fonts/ 目录里的字体安装到系统字体目录。"""
    if not os.path.isdir(FONT_DIR):
        print("！fonts/ 目录不存在，先把字体文件放到这里再执行 --install")
        return 1
    files = [f for f in sorted(os.listdir(FONT_DIR))
             if f.lower().endswith((".ttf", ".ttc", ".otf"))]
    if not files:
        print("！fonts/ 目录里没有字体文件（.ttf/.ttc/.otf）。可先用 --copy-from 从系统字体目录复制。")
        return 1
    targets = [d for d in system_font_dirs() if os.path.isdir(d)]
    if not targets:
        print("！未找到可用的系统字体目录")
        return 1
    target = targets[-1] if platform.system() != "Windows" else targets[0]
    print(f"将把 {len(files)} 个字体文件安装到：{target}")
    if platform.system() == "Windows" and target == WINDOWS_FONT_DIR:
        print("（Windows 需要管理员权限；如失败，请右键字体文件选择“为所有用户安装”）")
    if not assume_yes:
        answer = input("确认继续？[y/N] ").strip().lower()
        if answer not in ("y", "yes"):
            print("已取消。")
            return 0
    ok = 0
    for filename in files:
        source = os.path.join(FONT_DIR, filename)
        destination = os.path.join(target, filename)
        try:
            shutil.copy2(source, destination)
            print(f"已安装 {filename}")
            ok += 1
        except PermissionError:
            print(f"！权限不足，无法写入 {target}（请以管理员/sudo 重新运行）")
            break
        except OSError as error:
            print(f"！安装 {filename} 失败：{error}")
    print(f"\n完成：{ok}/{len(files)}")
    if ok:
        print("请重启 WPS/Word（必要时重启系统）后再重新生成公文。")
    if platform.system() == "Linux":
        print("提示：Linux 下建议执行 fc-cache -fv 刷新字体缓存。")
    return 0 if ok == len(files) else 1


def main(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    parser = argparse.ArgumentParser(description="公文字体检测与安装助手")
    parser.add_argument("--copy-from", metavar="目录",
                        help="从该目录复制公文字体到技能 fonts/ 目录（默认 C:\\Windows\\Fonts）")
    parser.add_argument("--install", action="store_true", help="把 fonts/ 里的字体安装到系统")
    parser.add_argument("-y", "--yes", action="store_true", help="安装时不再确认")
    args = parser.parse_args(argv)

    installed, resolved = detect()
    all_standard = report(installed, resolved)

    if args.copy_from:
        return copy_from(args.copy_from)
    if args.install:
        return install(assume_yes=args.yes)
    if not all_standard:
        print("\n可用参数：")
        print("  --copy-from C:\\Windows\\Fonts   把本机公文字体复制到 fonts/ 备份")
        print("  --install                        把 fonts/ 里的字体安装到系统字体目录")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
