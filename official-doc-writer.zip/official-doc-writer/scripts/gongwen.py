#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""党政机关公文生成器（GB/T 9704—2012《党政机关公文格式》）。

用法::

    python gongwen.py examples/01-通知.json -o 通知.docx
    python gongwen.py spec.json -o out.docx --output-format both
    python gongwen.py spec.json -o out.docx --output-format pdf
    python gongwen.py --ask --type 通知      # 一次问全（含交付格式）
    python gongwen.py spec.json --validate out.docx
    python gongwen.py --geometry out.docx
    python gongwen.py --fonts                      # 查看本机公文字体检测结果
    python gongwen.py --list-types                 # 查看支持的文种与结语

设计要点（每条实现都对照 GB/T 9704—2012 条文，条号见注释）：

* 版心 156mm×225mm，天头 37mm、订口 28mm，每面 22 行、每行 28 字（第 5 章）；
* 正文 3 号仿宋，标题 2 号小标宋，发文机关标志红色小标宋（7.2.4、7.3.1）；
* 结构层次序数 一、/（一）/1./（1） 依次用黑体/楷体/仿宋/仿宋（7.3.3）；
* 版头红色分隔线（7.2.7）、版记首末粗线中间细线（7.4.1）、版心外页码（7.5）；
* 附件另面编排、在版记之前（7.3.7）；上行文发文字号居左并与签发人同行（7.2.5、7.2.6）。

字体策略：优先使用标准公文字体（方正小标宋_GBK、仿宋_GB2312、黑体、楷体_GB2312），
本机缺失时自动回退到可用字体并给出警告，保证任何机器都能出文档。
"""

from __future__ import annotations


from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unicodedata
from typing import Any, Sequence

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt, RGBColor

# --------------------------------------------------------------------------
# 版面常量：GB/T 9704—2012 第 5 章
# --------------------------------------------------------------------------
PAGE_W_MM, PAGE_H_MM = 210.0, 297.0                              # 5.1 A4 幅面
MARGIN_TOP_MM = 37.0                                             # 5.2.1 天头
MARGIN_LEFT_MM = 28.0                                            # 5.2.1 订口
CONTENT_W_MM, CONTENT_H_MM = 156.0, 225.0                        # 5.2.1 版心
MARGIN_RIGHT_MM = PAGE_W_MM - MARGIN_LEFT_MM - CONTENT_W_MM      # 26mm
MARGIN_BOTTOM_MM = PAGE_H_MM - MARGIN_TOP_MM - CONTENT_H_MM      # 35mm

LINES_PER_PAGE = 22                                              # 5.2.3
CHARS_PER_LINE = 28                                              # 5.2.3
EFFECTIVE_CHARS_3 = 27.6        # 156mm 版心实际能放下的 3 号（16pt）汉字数
EFFECTIVE_CHARS_4 = 31.6        # 版记 4 号（14pt）每行容字量
MM2PT = 72 / 25.4

# 3.2 一行 = 一个汉字的高度 + 3 号汉字高度的 7/8
HANG_PT = 16.0                                                   # 3 号字高（磅）
LINE_PT_DEFINITION = HANG_PT * (1 + 7 / 8)                       # = 30pt
# 版面按“每面 22 行、撑满版心”落实（225mm/22 ≈ 28.99pt）；
# 两者相差约 1pt，为同时满足 5.2.3 行数与 5.2.1 版心，取撑满版心的固定行距。
LINE_PT = CONTENT_H_MM * MM2PT / LINES_PER_PAGE                   # 一行 ≈ 28.99pt

SIZE_3 = 16.0        # 三号
SIZE_2 = 22.0        # 二号
SIZE_4 = 14.0        # 四号

# 7.2.4／10.3 发文机关标志上边缘至版心上边缘的距离；10.2 命令（令）为 20mm
MARK_OFFSET_MM = 35.0
COMMAND_MARK_OFFSET_MM = 20.0
# 10.1 信函格式：发文机关标志上边缘至上页边 30mm
LETTER_MARK_TOP_MM = 30.0

RED = RGBColor(0xFF, 0x00, 0x00)
BLACK = RGBColor(0x00, 0x00, 0x00)

RULE_HEADER_PT = 1.5                       # 7.2.7 版头红色分隔线（标准未定厚度，通行 1.5pt）
RULE_HEADER_MM = 4.0                       # 7.2.7 发文字号之下 4mm
RULE_THICK_PT = 0.35 * MM2PT               # 7.4.1 版记粗线（推荐 0.35mm ≈ 1.0pt）
RULE_THIN_PT = 0.25 * MM2PT                # 7.4.1 版记细线（推荐 0.25mm ≈ 0.71pt）
LETTER_RULE_W_MM = 170.0
# 10.1 信函格式：标志上边缘距上页边 30mm，换算成相对版心上边缘的偏移（实测标定值）
LETTER_MARK_OFFSET_MM = -6.0                   # 10.1 信函格式红色双线线长 170mm

FOOTER_DISTANCE_MM = MARGIN_BOTTOM_MM - 7.0     # 7.5 一字线上距版心下边缘 7mm
LETTER_FOOTER_MM = 20.0                         # 10.1 第二条红色双线距下页边 20mm

# --------------------------------------------------------------------------
# 字体
# --------------------------------------------------------------------------
FONT_CANDIDATES: dict[str, list[str]] = {
    "fangsong": ["仿宋_GB2312", "仿宋", "FangSong_GB2312", "FangSong", "STFangsong"],
    "hei": ["黑体", "SimHei", "Microsoft YaHei"],
    "kai": ["楷体_GB2312", "楷体", "KaiTi_GB2312", "KaiTi", "STKaiti"],
    "xbs": ["方正小标宋_GBK", "方正小标宋简体", "FZXiaoBiaoSong-B05S",
            "方正小标宋_GBK 简体", "华文中宋", "STZhongsong", "宋体", "SimSun"],
    "song": ["宋体", "SimSun", "NSimSun", "新宋体"],
}

FONT_ROLE_ALIASES = {
    "仿宋": "fangsong", "仿宋体": "fangsong", "仿宋_gb2312": "fangsong", "fangsong": "fangsong",
    "黑体": "hei", "hei": "hei",
    "楷体": "kai", "楷体_gb2312": "kai", "kai": "kai",
    "小标宋": "xbs", "方正小标宋": "xbs", "方正小标宋_gbk": "xbs", "xbs": "xbs",
    "宋体": "song", "song": "song",
}

FALLBACK_NOTES = {
    "xbs": "未检测到方正小标宋_GBK，标题/发文机关标志回退为“{font}”（GB/T 9704—2012 7.2.4、7.3.1 推荐小标宋体字）。",
    "fangsong": "未检测到仿宋_GB2312/仿宋，正文回退为“{font}”。",
    "hei": "未检测到黑体，一级标题回退为“{font}”。",
    "kai": "未检测到楷体_GB2312/楷体，二级标题回退为“{font}”。",
    "song": "未检测到宋体，页码回退为“{font}”。",
}


# --------------------------------------------------------------------------
# 字体纵向度量：把“发文机关标志上边缘”落到精确位置（7.2.4／10.2／10.3）
# --------------------------------------------------------------------------
class FontMetrics:
    """一个字体在给定字号下的纵向度量（单位：磅，相对该行行首）。

    行高（含行距）= (ascent + descent + line_gap) × 字号；
    CJK 宋/黑/楷体系字体量不出 line_gap，此时按 1.3 倍字号估算（Word 默认单倍行距）。
    """

    def __init__(self, ascent_em: float, descent_em: float, line_gap_em: float = 0.0,
                 source: str = "内置度量表") -> None:
        self.ascent_em = ascent_em
        self.descent_em = descent_em
        self.line_gap_em = line_gap_em
        self.source = source

    def line_pt(self, size_pt: float) -> float:
        return (self.ascent_em + self.descent_em + self.line_gap_em) * size_pt

    def ascent_pt(self, size_pt: float) -> float:
        return self.ascent_em * size_pt

    def glyph_top_pt(self, size_pt: float) -> float:
        """行首到字面（汉字方框上边缘）的距离。"""
        return (self.line_pt(size_pt) - size_pt) / 2.0

    def baseline_pt(self, size_pt: float) -> float:
        return self.glyph_top_pt(size_pt) + self.ascent_pt(size_pt)


# 常见公文字体的纵向度量（em 相对值，典型值；本机装了对应字体文件时以文件真实度量为准）
# 小标宋取 0.880+0.120（行高≈字号），仿宋/黑体/楷体取 0.880+0.420（行高≈1.3 字号，
# 即 Word/WPS 中文字体常见的单倍行距），宋体取 1.060+0.340。
KNOWN_METRICS: dict[str, FontMetrics] = {
    "方正小标宋_gbk": FontMetrics(0.880, 0.120),
    "方正小标宋简体": FontMetrics(0.880, 0.120),
    "华文中宋": FontMetrics(1.060, 0.340),
    "stzhongsong": FontMetrics(1.060, 0.340),
    "仿宋_gb2312": FontMetrics(0.880, 0.420),
    "仿宋": FontMetrics(0.880, 0.420),
    "fangsong": FontMetrics(0.880, 0.420),
    "fangsong_gb2312": FontMetrics(0.880, 0.420),
    "stfangsong": FontMetrics(0.880, 0.420),
    "黑体": FontMetrics(0.880, 0.420),
    "simhei": FontMetrics(0.880, 0.420),
    "楷体_gb2312": FontMetrics(0.880, 0.420),
    "楷体": FontMetrics(0.880, 0.420),
    "kaiti": FontMetrics(0.880, 0.420),
    "kaiti_gb2312": FontMetrics(0.880, 0.420),
    "stkaiti": FontMetrics(0.880, 0.420),
    "宋体": FontMetrics(1.060, 0.340),
    "simsun": FontMetrics(1.060, 0.340),
    "nsimsun": FontMetrics(1.060, 0.340),
    "新宋体": FontMetrics(1.060, 0.340),
    "微软雅黑": FontMetrics(1.030, 0.270),
    "microsoft yahei": FontMetrics(1.030, 0.270),
}

METRICS_FALLBACK = FontMetrics(0.880, 0.420, source="缺省估算（行高 ≈ 1.3 × 字号）")
METRICS_CACHE: dict[tuple[str, str], FontMetrics] = {}


def font_file_for(name: str) -> str | None:
    """在常见字体目录中按文件名猜出字体文件路径（用于读取真实度量）。"""
    stem = re.sub(r"[^0-9a-z\u4e00-\u9fff]", "", str(name).lower())
    if not stem:
        return None
    directories = [
        os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts"),
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "fonts"),
        os.path.expanduser("~/.fonts"), os.path.expanduser("~/Library/Fonts"),
        "/usr/share/fonts",
    ]
    for directory in directories:
        if not directory or not os.path.isdir(directory):
            continue
        try:
            entries = sorted(os.listdir(directory))
        except OSError:
            continue
        for entry in entries:
            candidate = os.path.splitext(entry)[0].lower()
            if re.sub(r"[^0-9a-z\u4e00-\u9fff]", "", candidate) == stem and \
                    entry.lower().endswith((".ttf", ".otf", ".ttc")):
                return os.path.join(directory, entry)
    return None


def read_font_metrics(font_path: str) -> FontMetrics | None:
    """从 TTF／OTF 读取真实纵向度量；任何异常都返回 None（改用内置度量表）。"""
    try:
        from fontTools.ttLib import TTFont, TTCollection  # type: ignore
    except Exception:  # noqa: BLE001 - 未安装 fontTools 时用内置度量表
        return None
    try:
        if font_path.lower().endswith(".ttc"):
            font = TTCollection(font_path).fonts[0]
        else:
            font = TTFont(font_path, fontNumber=0, lazy=True)
        upm = float(font["head"].unitsPerEm) or 1000.0
        hhea = font["hhea"]
        ascent = hhea.ascent / upm
        descent = -hhea.descent / upm
        gap = getattr(hhea, "lineGap", 0) / upm
        return FontMetrics(ascent, descent, gap, source=os.path.basename(font_path))
    except Exception:  # noqa: BLE001
        return None


def metrics_for(font_name: str, *, probe: bool = True) -> FontMetrics:
    """取得字体度量：真实字体文件 → 内置度量表 → 缺省估算。"""
    key = (str(font_name).strip().lower(), "probe" if probe else "table")
    if key in METRICS_CACHE:
        return METRICS_CACHE[key]
    metrics: FontMetrics | None = None
    if probe:
        path = font_file_for(font_name)
        if path:
            metrics = read_font_metrics(path)
    if metrics is None:
        metrics = KNOWN_METRICS.get(str(font_name).strip().lower(), METRICS_FALLBACK)
    METRICS_CACHE[key] = metrics
    return metrics


# --------------------------------------------------------------------------
# 版头几何：发文机关标志上边缘精确落位（GB/T 9704—2012 7.2.4／7.2.7）
# --------------------------------------------------------------------------
def mark_line_height_pt(mark_font: str, mark_size_pt: float, line_pt: float = LINE_PT) -> float:
    """发文机关标志所在段落的行高。

    取“字体自然行高（含行距）”与“版心固定行距”的较大值：
    行高小于固定行距时按固定行距排（保持版心 22 行网格），否则按字体自然行高。
    """
    natural = metrics_for(mark_font).line_pt(mark_size_pt)
    return max(natural, line_pt)


def mark_baseline_pt(mark_font: str, mark_size_pt: float, offset_mm: float,
                     mode: str = "glyph", line_pt: float = LINE_PT) -> dict[str, float]:
    """把“发文机关标志上边缘”的目标位置换算成段落内基线位置。

    GB/T 9704—2012 7.2.4：“发文机关标志居中排布，上边缘至版心上边缘为 35mm”。
    “上边缘”有两种可核对的判定基准，用要素字段 ``mark_position`` 选择：

    * ``glyph``（默认）：标志**字面**（红色汉字方框）上边缘落在版心上边缘下 35mm
      —— 与“把样张放在尺子下量”的结果一致，已用渲染图逐像素校准；
    * ``data_box``：标志所在**行**的上边缘落在版心上边缘下 35mm
      —— 按“行框对齐版心”的理解，实际字面会低约 1.4mm。
    """
    line_height = mark_line_height_pt(mark_font, mark_size_pt, line_pt)
    ascent = metrics_for(mark_font).ascent_pt(mark_size_pt)
    inset = max(0.0, (line_height - mark_size_pt) / 2.0)
    target = offset_mm * MM2PT
    if mode == "data_box":
        # 让所在行的上边缘落在目标位置：字面再往下半个“行高与字号之差”
        baseline = target + inset + ascent
        glyph_top = target + inset
    else:
        # 让字面上边缘正好落在目标位置
        baseline = target + ascent
        glyph_top = target
    return {
        "line_height_pt": line_height,
        "ascent_pt": ascent,
        "glyph_inset_pt": inset,
        "baseline_pt": baseline,
        "glyph_top_pt": glyph_top,
    }


def mark_placement(*, mark_font: str, mark_size_pt: float, header_lines: int = 0,
                   offset_mm: float = MARK_OFFSET_MM, mode: str = "glyph",
                   line_pt: float = LINE_PT) -> dict[str, Any]:
    """算出“发文机关标志”的排版参数：需要多少段前距、是否需要压缩天头。

    段前距 = （段落行首相对本节版心上边缘的位置） − 前面份号/密级/紧急程度占的行数；
    为负说明“前面几行 + 本行”已经超过目标位置，此时把它记进 ``top_trim_pt``，
    由调用方从本节天头里剪掉，保证版心仍是 225mm 高、标志仍精确落位。
    """
    mark_font = str(mark_font)
    box = mark_baseline_pt(mark_font, mark_size_pt, offset_mm, mode, line_pt)
    line_height = box["line_height_pt"]
    line_start = box["baseline_pt"] - line_height
    raw_space = line_start - header_lines * line_pt
    top_trim = max(0.0, -raw_space)
    space = max(0.0, raw_space)
    # 剪了多少天头，字面上边缘距上页边就相应减少多少
    top_from_content = box["glyph_top_pt"] / MM2PT
    top_from_page = (MARGIN_TOP_MM - top_trim / MM2PT + top_from_content
                     if offset_mm > 0 else top_from_content)
    return {
        "offset_mm": round(offset_mm, 3),
        "target_mm": round(offset_mm, 3),
        "header_lines": header_lines,
        "mode": mode,
        "line_height_pt": round(line_height, 3),
        "ascent_pt": round(box["ascent_pt"], 3),
        "glyph_inset_pt": round(box["glyph_inset_pt"], 3),
        "space_raw_pt": round(raw_space, 3),
        "space_before_pt": round(space, 3),
        "top_trim_pt": round(top_trim, 3),
        "mark_top_from_content_mm": round(top_from_content, 3),
        "mark_top_from_page_mm": round(top_from_page, 3),
        "metrics_source": metrics_for(mark_font).source,
    }


def mark_space_before_pt(**kwargs: Any) -> tuple[float, dict[str, Any]]:
    """兼容旧调用：返回 (段前距磅值, 排版参数)。新代码用 :func:`mark_placement`。"""
    placement = mark_placement(**kwargs)
    return placement["space_before_pt"], placement


def detect_installed_fonts() -> set[str]:
    """尽力探测本机已安装字体（Windows 注册表 + 字体目录 + fc-list）。"""
    names: set[str] = set()
    try:
        import winreg  # type: ignore

        for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            try:
                with winreg.OpenKey(
                        hive, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts") as key:
                    index = 0
                    while True:
                        try:
                            value_name, value_data, _ = winreg.EnumValue(key, index)
                        except OSError:
                            break
                        index += 1
                        names.add(re.sub(r"\s*\(.*?\)\s*$", "", value_name).strip())
                        if isinstance(value_data, str):
                            names.add(os.path.splitext(os.path.basename(value_data))[0])
            except OSError:
                continue
    except Exception:  # noqa: BLE001 - 非 Windows 平台
        pass

    for directory in (
            os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts"),
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "Windows", "Fonts"),
            os.path.expanduser("~/.fonts"), os.path.expanduser("~/Library/Fonts"),
            "/usr/share/fonts"):
        if directory and os.path.isdir(directory):
            try:
                for entry in os.listdir(directory):
                    names.add(os.path.splitext(entry)[0])
            except OSError:
                continue

    fc_list = shutil.which("fc-list")
    if fc_list:
        try:
            out = subprocess.run([fc_list, ":", "family"], capture_output=True, timeout=10,
                                 check=False, encoding="utf-8", errors="replace").stdout
            for line in out.splitlines():
                for part in line.split(","):
                    if part.strip():
                        names.add(part.strip())
        except Exception:  # noqa: BLE001
            pass
    return {n for n in names if n}


class FontResolver:
    """把字体角色解析成实际字体名，并记录回退警告。"""

    def __init__(self, installed: set[str] | None = None, mode: str = "auto",
                 overrides: dict[str, str] | None = None) -> None:
        self.installed = installed if installed is not None else detect_installed_fonts()
        self.mode = mode                       # auto | standard
        self.overrides = {k.lower(): v for k, v in (overrides or {}).items()}
        self.resolved: dict[str, str] = {}
        self.warnings: list[str] = []

    def _is_installed(self, name: str) -> bool:
        if not self.installed:
            return True                        # 探测不到就假定可用，交给 Word 替换
        return name.lower() in {n.lower() for n in self.installed}

    def resolve(self, role: str) -> str:
        role = FONT_ROLE_ALIASES.get(role.lower().strip(), role.lower().strip())
        if role in self.resolved:
            return self.resolved[role]
        if role in self.overrides:
            self.resolved[role] = self.overrides[role]
            return self.resolved[role]

        candidates = FONT_CANDIDATES.get(role, [role])
        if self.mode == "standard":
            chosen = candidates[0]
        else:
            chosen = next((c for c in candidates if self._is_installed(c)), candidates[0])
        if chosen != candidates[0] and role in FALLBACK_NOTES:
            self.warnings.append(FALLBACK_NOTES[role].format(font=chosen))
        self.resolved[role] = chosen
        return chosen

    def as_dict(self) -> dict[str, str]:
        return {role: self.resolve(role) for role in FONT_CANDIDATES}


# --------------------------------------------------------------------------
# 文本度量与 OOXML 小工具
# --------------------------------------------------------------------------
def text_width(text: str) -> float:
    """按版心字数估算宽度：全角 1、半角 0.5。"""
    width = 0.0
    for ch in text:
        width += 0.5 if unicodedata.east_asian_width(ch) in ("Na", "H") else 1.0
    return width


def count_lines(text: str, left_chars: float = 0.0, first_line_chars: float = 0.0,
                chars_per_line: float | None = None) -> int:
    """估算段落占用行数（版记沉底定位用）。

    注意：156mm 版心放不下 28 个 3 号（16pt）汉字，实际一行约 27.6 字；
    版记为 4 号（14pt），一行约 31.6 字。这里按实际容字量估算。
    """
    capacity = chars_per_line if chars_per_line is not None else EFFECTIVE_CHARS_3
    if not text:
        return 1
    lines = 1
    remaining = text_width(text) - (capacity - left_chars - first_line_chars)
    while remaining > 0:
        lines += 1
        remaining -= max(1.0, capacity - left_chars)
    return max(1, lines)


def count_lines_by_capacity(text: str, first_capacity: float, rest_capacity: float) -> int:
    """按首行/回行不同容字量估算行数（版记左空一字、回行与冒号后首字对齐）。"""
    if not text:
        return 1
    remaining = text_width(text) - first_capacity
    lines = 1
    while remaining > 0:
        lines += 1
        remaining -= rest_capacity
    return lines


def _el(tag: str, **attrs: Any):
    element = OxmlElement(tag)
    for key, value in attrs.items():
        element.set(qn(f"w:{key}"), str(value))
    return element


def set_run_font(run, font_name: str, size_pt: float, *, bold: bool = False,
                 color: RGBColor | None = None, western: str | None = None) -> None:
    """设置中英文字体；中文必须显式写 w:eastAsia，否则 Word 不应用。"""
    run.font.name = western or font_name
    run.font.size = Pt(size_pt)
    run.font.bold = bold
    run.font.color.rgb = color if color is not None else BLACK
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for attr in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
        rfonts.set(qn(attr), font_name if attr == "w:eastAsia" else (western or font_name))


def _no_snap(paragraph) -> None:
    """关闭“对齐到网格”，避免 docGrid 干扰固定行距（尤其分隔线的精确位置）。"""
    ppr = paragraph._p.get_or_add_pPr()
    snap = ppr.find(qn("w:snapToGrid"))
    if snap is None:
        snap = OxmlElement("w:snapToGrid")
        ppr.append(snap)
    snap.set(qn("w:val"), "0")


def _set_char_indent(paragraph, size_pt: float, *, first_line_chars: float = 0.0,
                     left_chars: float = 0.0, right_chars: float = 0.0) -> None:
    """按“字”设置缩进（3.1 一字 = 一个汉字宽）。同时写 *Chars 与 twips，
    保证 Word（用 *Chars）与 LibreOffice（用 twips）表现一致。"""
    pf = paragraph.paragraph_format
    if left_chars:
        pf.left_indent = Pt(left_chars * size_pt)
    if right_chars:
        pf.right_indent = Pt(right_chars * size_pt)
    if first_line_chars:
        pf.first_line_indent = Pt(first_line_chars * size_pt)
    if left_chars or right_chars or first_line_chars:
        ppr = paragraph._p.get_or_add_pPr()
        ind = ppr.find(qn("w:ind"))
        if ind is None:
            ind = OxmlElement("w:ind")
            ppr.append(ind)
        if left_chars:
            ind.set(qn("w:leftChars"), str(int(round(left_chars * 100))))
        if right_chars:
            ind.set(qn("w:rightChars"), str(int(round(right_chars * 100))))
        if first_line_chars:
            ind.set(qn("w:firstLineChars"), str(int(round(first_line_chars * 100))))


def _set_right_indent_exact(paragraph, right_pt: float, size_pt: float) -> None:
    """按精确磅值设置右缩进，同时写 w:rightChars 让 Word 显示为“空 N 字”。

    署名、成文日期、版记印发机关都要靠右对齐到“字”为单位的精确位置，
    只写字符数会因行宽不足 28 字（3 号字一行约 27.6 字）而累积误差。
    """
    pf = paragraph.paragraph_format
    pf.right_indent = Pt(right_pt)
    ppr = paragraph._p.get_or_add_pPr()
    ind = ppr.find(qn("w:ind"))
    if ind is None:
        ind = OxmlElement("w:ind")
        ppr.append(ind)
    ind.set(qn("w:rightChars"), str(int(round(right_pt / size_pt * 100))))


def _set_line_spacing(paragraph, line_pt: float = LINE_PT) -> None:
    """全篇统一固定行距：225mm/22 行 ≈ 28.99pt，撑满版心。"""
    pf = paragraph.paragraph_format
    pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
    pf.line_spacing = Pt(line_pt)
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)


def _set_border(paragraph, *, top: tuple[float, str] | None = None,
                bottom: tuple[float, str] | None = None,
                line_width_pt: float | None = None) -> None:
    """给段落加分隔线（版头红线、版记三条线都用它）。thickness_pt 为线粗。

    line_width_pt 给定时，用左右缩进把分隔线定位为指定长度并居中，
    用于信函格式 10.1 的 170mm 红色双线（比版心 156mm 宽）。
    """
    ppr = paragraph._p.get_or_add_pPr()
    borders = ppr.find(qn("w:pBdr"))
    if borders is None:
        borders = OxmlElement("w:pBdr")
        ppr.append(borders)
    for edge, spec in (("top", top), ("bottom", bottom)):
        if spec is None:
            continue
        thickness_pt, color = spec
        borders.append(_el(f"w:{edge}", val="single", sz=max(2, int(round(thickness_pt * 8))),
                           space="0", color=color))
    if line_width_pt:
        inset = max(0.0, (CONTENT_W_MM * MM2PT - line_width_pt) / 2.0)
        if inset:
            pf = paragraph.paragraph_format
            pf.left_indent = Pt(inset)
            pf.right_indent = Pt(inset)


def _add_field(paragraph, instruction: str) -> None:
    """插入域代码（页码域）。"""
    run = paragraph.add_run()
    run._r.append(_el("w:fldChar", fldCharType="begin"))
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = instruction
    run._r.append(instr)
    run._r.append(_el("w:fldChar", fldCharType="end"))


def _set_doc_grid(section, line_pitch_twips: int = int(round(LINE_PT * 20))) -> None:
    """写入 w:docGrid，令 Word 也按 22 行/页的行网格排版。"""
    sect_pr = section._sectPr
    grid = sect_pr.find(qn("w:docGrid"))
    if grid is None:
        grid = OxmlElement("w:docGrid")
        sect_pr.append(grid)
    grid.set(qn("w:type"), "lines")
    grid.set(qn("w:linePitch"), str(line_pitch_twips))


def _set_section_v_align(section, value: str = "bottom") -> None:
    """把本节内容垂直对齐到版心底部（用于版记沉底，schema 顺序在 w:docGrid 之前）。"""
    sect_pr = section._sectPr
    element = sect_pr.find(qn("w:vAlign"))
    if element is None:
        element = OxmlElement("w:vAlign")
        grid = sect_pr.find(qn("w:docGrid"))
        if grid is not None:
            grid.addprevious(element)
        else:
            sect_pr.append(element)
    element.set(qn("w:val"), value)


LEVEL_FONTS = {1: "hei", 2: "kai", 3: "fangsong", 4: "fangsong"}
LEVEL_PATTERNS = [
    (1, re.compile(r"^[一二三四五六七八九十百]+、")),
    (2, re.compile(r"^[（(][一二三四五六七八九十百]+[）)]")),
    (3, re.compile(r"^\d+\s*[.．]")),
    (4, re.compile(r"^[（(]\d+[）)]")),
]

DOC_TYPES = ["决议", "决定", "命令（令）", "公报", "公告", "通告", "意见", "通知", "通报",
             "报告", "请示", "批复", "议案", "函", "纪要"]
UPWARD_TYPES = {"请示", "报告", "意见", "议案"}          # 上行文：需标注签发人

# 《党政机关公文处理工作条例》第八条 + 通行写作规范
CLOSING_WORDS = {
    "通知": ["特此通知。", "请认真贯彻执行。"],
    "通报": ["特此通报。"],
    "报告": ["特此报告。", "以上报告，请审阅。"],
    "请示": ["妥否，请批示。", "以上请示，请予批复。"],
    "批复": ["此复。", "特此批复。"],
    "函": ["请予支持为盼。", "请予研究函复。", "特此函告。"],
    "公告": ["特此公告。"],
    "通告": ["特此通告。"],
    "议案": ["请予审议。"],
    # 决议、决定、命令（令）、意见、公报、纪要一般不用结语，正文写完即止
    "决议": [],
    "决定": [],
    "命令（令）": [],
    "命令": [],
    "意见": [],
    "公报": [],
    "纪要": [],
}
# 允许的通用结尾语（校验器用）
COMMON_CLOSINGS = {"特此通知。", "特此通报。", "特此报告。", "以上报告，请审阅。",
                   "妥否，请批示。", "以上请示，请予批复。", "请予支持为盼。",
                   "请予研究函复。", "特此函告。", "此复。", "特此批复。", "特此公告。",
                   "特此通告。", "特此决定。", "此令。", "特此函复。", "请予审议。",
                   "特此决议。", "请予审批。", "请予核准。"}


class SpecError(ValueError):
    """公文要素不合法。"""


def normalize_spec(raw: dict[str, Any]) -> dict[str, Any]:
    """补齐默认值并做最小合法性检查。"""
    if not isinstance(raw, dict):
        raise SpecError("公文要素必须是 JSON 对象")
    spec = dict(raw)
    spec.setdefault("format", "standard")
    spec.setdefault("doc_type", "")
    spec.setdefault("body", [])
    if spec["format"] == "letter":
        spec.setdefault("page_number", False)      # 10.1 首页不显示页码
    else:
        spec.setdefault("page_number", True)
    spec.setdefault("version_record_placement", "new_page")

    if spec.get("doc_number"):
        number = str(spec["doc_number"]).strip()
        if not re.search(r"〔\d{4}〕", number):
            raise SpecError(
                f"发文字号须含六角括号年份，如“沈数据〔2026〕1号”，当前为“{number}”")
    date = str(spec.get("date") or "").strip()
    if date and not re.fullmatch(r"\d{4}年\d{1,2}月\d{1,2}日", date):
        raise SpecError(f"成文日期应为“2026年3月13日”形式且月、日不编虚位，当前为“{date}”")
    if spec.get("copy_number"):
        spec["copy_number"] = f"{int(str(spec['copy_number'])):06d}"
    return spec


# --------------------------------------------------------------------------
# 生成器
# --------------------------------------------------------------------------
class GongwenBuilder:
    """把一份公文要素（dict）渲染成符合 GB/T 9704—2012 的 DOCX。"""

    def __init__(self, spec: dict[str, Any], resolver: FontResolver | None = None) -> None:
        self.spec = normalize_spec(spec)
        self.fonts = resolver or FontResolver()
        self.doc = Document()
        self.used_pt = 0.0
        self.content_lines = 0.0
        self.plan: list[dict[str, Any]] = []
        self.mark_gap: dict[str, Any] = {}
        self.layout: dict[str, Any] = {}
        self.record_only_sections: set[int] = set()
        self._setup_styles()
        # 先算好发文机关标志的位置：天头可能要剪一点，_setup_section 用得上
        self.mark_gap = self._mark_placement()
        self._setup_section()

    # ---------------------------------------------------------------- 基础
    @property
    def fmt(self) -> str:
        return self.spec["format"]

    def font(self, role: str) -> str:
        return self.fonts.resolve(role)

    # ------------------------------------------------------------ 红头位置
    def _mark_config(self) -> tuple[str, float, float, int]:
        """返回 (标志字体, 标志字号, 目标偏移mm, 前面份号/密级/紧急程度占的行数)。"""
        fmt = self.fmt
        mark_size = float(self.spec.get("issuer_mark_size")
                          or (26.0 if fmt == "command" else 22.0))
        header_lines = 0
        if fmt == "standard":
            header_lines = sum(1 for key in ("copy_number", "secrecy", "urgency")
                               if self.spec.get(key))
        if fmt == "letter":
            # 10.1：发文机关标志上边缘距**上页边** 30mm（不是距版心上边缘）。
            # 天头 37mm，故它落在版心上边缘往上约 6mm 处；该值用实测标定过
            # （scripts 侧的校准脚本：-7.0→28.59mm、-6.0→29.60mm、-5.0→30.60mm）。
            offset = LETTER_MARK_OFFSET_MM
        elif fmt == "command":
            offset = COMMAND_MARK_OFFSET_MM
        else:
            offset = MARK_OFFSET_MM
        # 允许用要素字段微调（信函等距“上页边”的版式靠它精确标定）
        if self.spec.get("mark_offset_mm") is not None:
            offset = float(self.spec["mark_offset_mm"])
        return self.font("xbs"), mark_size, offset, header_lines

    def _mark_placement(self) -> dict[str, Any]:
        if self.fmt == "no_header":
            return {}
        if not (self.spec.get("issuer_mark") or self.spec.get("issuer")):
            return {}
        mark_font, mark_size, offset, header_lines = self._mark_config()
        mode = str(self.spec.get("mark_position") or "glyph")
        return mark_placement(mark_font=mark_font, mark_size_pt=mark_size,
                              header_lines=header_lines, offset_mm=offset, mode=mode)

    def _setup_styles(self) -> None:
        style = self.doc.styles["Normal"]
        style.font.name = self.font("fangsong")
        style.font.size = Pt(SIZE_3)
        rpr = style.element.get_or_add_rPr()
        rfonts = rpr.find(qn("w:rFonts"))
        if rfonts is None:
            rfonts = OxmlElement("w:rFonts")
            rpr.insert(0, rfonts)
        for attr in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
            rfonts.set(qn(attr), self.font("fangsong"))
        pf = style.paragraph_format
        pf.line_spacing_rule = WD_LINE_SPACING.EXACTLY
        pf.line_spacing = Pt(LINE_PT)
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)
        ppr = style.element.get_or_add_pPr()
        snap = OxmlElement("w:snapToGrid")
        snap.set(qn("w:val"), "0")
        ppr.append(snap)

    def _setup_section(self) -> None:
        section = self.doc.sections[0]
        section.page_width = Mm(PAGE_W_MM)
        section.page_height = Mm(PAGE_H_MM)
        # 天头统一 37mm；各版式红头的目标位置由 mark_placement 的 offset 表达
        # （standard/minutes 35mm、command 20mm、letter 30mm——见 7.2.4 / 10.2 / 10.3 / 10.1）。
        # 版头若干行 + 标志行高超过目标位置时，剪掉一点天头才能精确落位，而不是被夹到 0 后整体下沉。
        trim_mm = float(self.mark_gap.get("top_trim_pt") or 0.0) / MM2PT
        top_mm = max(5.0, MARGIN_TOP_MM - trim_mm)
        section.top_margin = Mm(top_mm)
        section.left_margin = Mm(MARGIN_LEFT_MM)
        section.right_margin = Mm(MARGIN_RIGHT_MM)
        # 版心高度固定 225mm：天头剪多少，下白边就补多少
        section.bottom_margin = Mm(PAGE_H_MM - top_mm - CONTENT_H_MM)
        section.header_distance = Mm(20)
        section.footer_distance = Mm(LETTER_FOOTER_MM if self.fmt == "letter"
                                     else FOOTER_DISTANCE_MM)
        _set_doc_grid(section)

    # ------------------------------------------------------------ 段落原语
    def para(self, text: str = "", *, font: str | None = None, size: float = SIZE_3,
             bold: bool = False, color: RGBColor | None = None,
             align: str = "justify", space_before_pt: float = 0.0,
             first_line_chars: float = 0.0, left_chars: float = 0.0,
             right_chars: float = 0.0, line_pt: float = LINE_PT,
             runs: Sequence[tuple[str, str, float, bool]] | None = None,
             top_border: tuple[float, str] | None = None,
             bottom_border: tuple[float, str] | None = None,
             role: str = "正文", count: bool = True,
             tab_right_chars: float | None = None,
             page_break_before: bool = False) -> Any:
        """添加一个公文段落；runs 给定时按 (文本, 字体, 字号, 加粗) 依次落地。"""
        paragraph = self.doc.add_paragraph()
        paragraph.alignment = {
            "left": WD_ALIGN_PARAGRAPH.LEFT,
            "center": WD_ALIGN_PARAGRAPH.CENTER,
            "right": WD_ALIGN_PARAGRAPH.RIGHT,
            "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
        }[align]
        _set_line_spacing(paragraph, line_pt)
        _no_snap(paragraph)
        _set_char_indent(paragraph, size, first_line_chars=first_line_chars,
                         left_chars=left_chars, right_chars=right_chars)
        if space_before_pt:
            paragraph.paragraph_format.space_before = Pt(space_before_pt)
        if tab_right_chars is not None:
            position = Pt(CONTENT_W_MM * MM2PT - tab_right_chars * size)
            paragraph.paragraph_format.tab_stops.add_tab_stop(
                position, WD_TAB_ALIGNMENT.RIGHT)
        if top_border or bottom_border:
            _set_border(paragraph, top=top_border, bottom=bottom_border)
        if page_break_before:
            paragraph.paragraph_format.page_break_before = True

        if runs is None:
            runs = ((text, font or self.font("fangsong"), size, bold),) if text else ()
        for run_text, run_font, run_size, run_bold in runs:
            run = paragraph.add_run(run_text)
            set_run_font(run, run_font, run_size, bold=run_bold, color=color)

        if count:
            self.used_pt += space_before_pt + count_lines(text, left_chars, first_line_chars) * LINE_PT
        self.plan.append({
            "role": role, "text": text, "font": font or self.font("fangsong"),
            "size": size, "align": align, "bold": bold,
            "left_chars": left_chars, "first_line_chars": first_line_chars,
            "right_chars": right_chars, "line_pt": line_pt,
            "space_before_pt": space_before_pt,
        })
        return paragraph

    def blank(self, count: int = 1, *, line_pt: float = LINE_PT,
              break_before: bool = False) -> None:
        for index in range(count):
            self.para("", role="空行", line_pt=line_pt,
                      page_break_before=break_before and index == 0)

    def rule(self, *, height_pt: float, thickness_pt: float | None = None,
             color: str = "FF0000", top: bool = False, bottom: bool = True,
             role: str = "分隔线", left_chars: float = 0.0,
             right_chars: float = 0.0, space_before_pt: float = 0.0,
             line_width_pt: float | None = None) -> None:
        """分隔线：用一个极扁的空段落承载上/下边框；height_pt 是线距上一行的距离。"""
        paragraph = self.doc.add_paragraph()
        _set_line_spacing(paragraph, height_pt)
        _no_snap(paragraph)
        if space_before_pt:
            paragraph.paragraph_format.space_before = Pt(space_before_pt)
        if left_chars or right_chars:
            _set_char_indent(paragraph, SIZE_3, left_chars=left_chars, right_chars=right_chars)
        spec = (thickness_pt if thickness_pt is not None else RULE_THICK_PT, color)
        _set_border(paragraph, top=spec if top else None, bottom=spec if bottom else None,
                    line_width_pt=line_width_pt)
        run = paragraph.add_run("")
        set_run_font(run, self.font("fangsong"), SIZE_3)
        self.used_pt += space_before_pt + height_pt
        self.plan.append({"role": role, "text": "", "height_pt": height_pt,
                          "space_before_pt": space_before_pt,
                          "line_width_pt": line_width_pt,
                          "thickness_pt": spec[0], "color": color})

    # --------------------------------------------------------------- 版头
    def build_header(self) -> None:
        """7.2 版头 / 10.1 信函格式 / 10.2 命令格式 / 10.3 纪要格式 的标志区。"""
        spec, fmt = self.spec, self.fmt
        if fmt == "no_header":
            return

        header_lines = 0
        if fmt == "standard":
            if spec.get("copy_number"):                 # 7.2.1 份号：6 位 3 号阿拉伯数字
                self.para(str(spec["copy_number"]), align="left", role="份号")
                header_lines += 1
            if spec.get("secrecy"):                     # 7.2.2 密级和保密期限：3 号黑体
                self.para(spec["secrecy"], font=self.font("hei"), align="left",
                          role="密级和保密期限")
                header_lines += 1
            if spec.get("urgency"):                     # 7.2.3 紧急程度：3 号黑体
                self.para(spec["urgency"], font=self.font("hei"), align="left",
                          role="紧急程度")
                header_lines += 1

        mark = spec.get("issuer_mark") or self._default_issuer_mark()
        if mark:
            mark_font, mark_size, _offset, _lines = self._mark_config()
            space = float(self.mark_gap.get("space_before_pt") or 0.0)
            # GB/T 9704—2012 7.2.4：发文机关标志居中，上边缘至版心上边缘 35mm
            #（10.2 命令（令）为 20mm；10.1 信函格式为上边缘至上页边 30mm）
            self.para(mark, font=mark_font, size=mark_size, color=RED,
                      align="center", space_before_pt=space, role="发文机关标志")
            self.mark_gap["source"] = {"role": "发文机关标志", "text": mark,
                                       "font": mark_font, "size": mark_size,
                                       "space_before_pt": round(space, 3),
                                       "top_trim_pt": self.mark_gap.get("top_trim_pt", 0.0)}
            self.plan.append({"role": "发文机关标志", "text": mark, "font": mark_font,
                              "size": mark_size, "color": "FF0000",
                              "space_before_pt": round(space, 3),
                              "gap": dict(self.mark_gap)})

        if fmt == "letter":
            # 10.1 发文机关标志下 4mm 处印一条红色双线（上粗下细），线长 170mm 居中
            self.rule(height_pt=4 * MM2PT - RULE_HEADER_PT, thickness_pt=RULE_HEADER_PT,
                      color="FF0000", role="信函红色双线（上粗）",
                      line_width_pt=LETTER_RULE_W_MM * MM2PT)
            self.rule(height_pt=1.2, thickness_pt=RULE_THIN_PT, color="FF0000",
                      role="信函红色双线（下细）",
                      line_width_pt=LETTER_RULE_W_MM * MM2PT)
            if spec.get("doc_number"):                  # 10.1 发文字号顶格居版心右边缘
                self.para(str(spec["doc_number"]), align="right", role="发文字号")
            return

        if spec.get("doc_number") and fmt in ("standard", "minutes"):
            self._doc_number_line()                     # 7.2.5 / 7.2.6
        if fmt in ("standard", "minutes"):
            # 7.2.7 发文字号之下 4mm 处居中一条与版心等宽的红色分隔线
            self.rule(height_pt=RULE_HEADER_MM * MM2PT - RULE_HEADER_PT,
                      thickness_pt=RULE_HEADER_PT, color="FF0000", role="版头红色分隔线")
        elif fmt == "command" and spec.get("doc_number"):
            self.para(str(spec["doc_number"]), align="left", role="发文字号")

    def _default_issuer_mark(self) -> str:
        issuer = str(self.spec.get("issuer") or "").strip()
        if not issuer:
            return ""
        if self.fmt == "command":
            return issuer if issuer.endswith(("命令", "令")) else f"{issuer}令"
        if self.fmt == "minutes":
            return issuer if issuer.endswith("纪要") else f"{issuer}纪要"
        if issuer.endswith("文件"):
            return issuer
        return f"{issuer}文件"

    def _doc_number_line(self) -> None:
        """7.2.5 下行文发文字号居中；上行文居左空一字并与最后一个签发人姓名同行。"""
        spec = self.spec
        doc_number = str(spec["doc_number"])
        signers = [str(s) for s in (spec.get("signers") or [])]
        if not signers:
            # 7.2.5 编排在发文机关标志下空二行位置，居中
            self.para(doc_number, align="center", space_before_pt=2 * LINE_PT,
                      role="发文字号")
            return
        chunks = [signers[i:i + 2] for i in range(0, len(signers), 2)]     # 每行排两个姓名
        for index, chunk in enumerate(chunks):
            self._signer_line(doc_number if index == len(chunks) - 1 else "", chunk,
                              space_before_pt=2 * LINE_PT if index == 0 else 0.0)

    def _signer_line(self, doc_number: str, names: Sequence[str],
                     *, space_before_pt: float = 0.0) -> None:
        """7.2.6 签发人：“签发人”三字加全角冒号用仿宋，姓名用楷体，居右空一字。"""
        paragraph = self.doc.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        _set_line_spacing(paragraph)
        _no_snap(paragraph)
        if space_before_pt:
            paragraph.paragraph_format.space_before = Pt(space_before_pt)
        _set_char_indent(paragraph, SIZE_3, left_chars=1.0)
        position = Pt(CONTENT_W_MM * MM2PT - 1.0 * SIZE_3)
        paragraph.paragraph_format.tab_stops.add_tab_stop(position, WD_TAB_ALIGNMENT.RIGHT)
        texts: list[str] = []
        if doc_number:
            run = paragraph.add_run(doc_number + "\t")
            set_run_font(run, self.font("fangsong"), SIZE_3)
            texts.append(doc_number)
        for index, name in enumerate(names):
            label = paragraph.add_run("签发人：" if index == 0 else "　　签发人：")
            set_run_font(label, self.font("fangsong"), SIZE_3)
            person = paragraph.add_run(name)
            set_run_font(person, self.font("kai"), SIZE_3)
            texts.append(name)
        self.used_pt += space_before_pt + LINE_PT
        self.plan.append({"role": "发文字号/签发人", "text": " ".join(texts),
                          "font": "仿宋+楷体", "size": SIZE_3, "align": "left",
                          "left_chars": 1.0, "space_before_pt": space_before_pt})

    # --------------------------------------------------------------- 主体
    def build_body(self) -> None:
        """7.3 主体：标题、主送机关、正文、附件说明、署名、成文日期、附注。"""
        spec, fmt = self.spec, self.fmt
        pending_pt = 0.0

        if fmt == "command" and spec.get("command_number"):
            self.para(str(spec["command_number"]), align="center",
                      space_before_pt=2 * LINE_PT, role="令号")      # 10.2 标志下空二行
            pending_pt = 2 * LINE_PT
        if spec.get("title"):
            # 7.3.1 版头红色分隔线下空二行；10.1 信函格式标题与上一要素相距二行
            self._title(space_before_pt=pending_pt or (2 * LINE_PT if fmt in
                                                       ("standard", "minutes", "letter")
                                                       else 0.0))
            pending_pt = 0.0
        if spec.get("recipient") and not spec.get("recipient_in_record"):
            self.para(spec["recipient"], align="left",
                      space_before_pt=pending_pt or LINE_PT, role="主送机关")
            pending_pt = 0.0
        self._body_paragraphs(leading_space_pt=pending_pt)
        self._attachment_note()
        if fmt == "minutes":
            self._minutes_attendees()
        self._signature_block()
        if spec.get("note"):
            note = str(spec["note"]).strip()
            if not (note.startswith("（") or note.startswith("(")):
                note = f"（{note}）"
            self.para(note, align="left", left_chars=2.0, space_before_pt=LINE_PT,
                      role="附注")

    def _title(self, *, space_before_pt: float) -> None:
        """7.3.1 标题：2 号小标宋，红色分隔线下空二行，居中，回行呈梯形或菱形。
        subtitle 用于决议、公报等标题下的“（××××年×月×日××会议通过）”一类标注。"""
        lines = self.spec.get("title_lines") or [str(self.spec["title"])]
        for index, line in enumerate(lines):
            self.para(line, font=self.font("xbs"), size=SIZE_2, align="center",
                      space_before_pt=space_before_pt if index == 0 else 0.0,
                      role="标题" if index == 0 else "标题（回行）")
        if self.spec.get("subtitle"):
            self.para(str(self.spec["subtitle"]), size=SIZE_3, align="center",
                      role="标题下标注")

    def _body_paragraphs(self, *, leading_space_pt: float = 0.0) -> None:
        """7.3.3 正文：3 号仿宋，每段左空二字、回行顶格，层次序数分字体。"""
        first = True
        for item in self.spec.get("body") or []:
            if isinstance(item, str):
                self._body_paragraph(item, space_before_pt=leading_space_pt if first else 0.0)
                first = False
            elif isinstance(item, dict):
                kind = item.get("type", "para")
                if kind == "blank":
                    self.blank(int(item.get("count", 1)))
                elif kind == "table":
                    self._table(item)
                elif kind == "rule":
                    self.rule(height_pt=float(item.get("height_pt", 1.0)),
                              thickness_pt=float(item.get("thickness_pt", 1.0)),
                              color=str(item.get("color", "000000")))
                elif kind == "pagebreak":
                    self.para("", role="分页", page_break_before=True)
                else:
                    self._body_paragraph(item.get("text", "") or "",
                                         level=item.get("level"), font=item.get("font"),
                                         size=item.get("size"), bold=item.get("bold"),
                                         align=item.get("align"),
                                         space_before_pt=(leading_space_pt if first else 0.0))
                    first = False
            else:
                raise SpecError(f"body 中不支持的条目类型：{type(item)!r}")

    def _body_paragraph(self, text: str, *, level: int | None = None,
                        font: str | None = None, size: float | None = None,
                        bold: bool | None = None, align: str | None = None,
                        space_before_pt: float = 0.0) -> None:
        if not text:
            self.blank()
            return
        if level is None:
            level = 0
            for candidate, pattern in LEVEL_PATTERNS:
                if pattern.match(text):
                    level = candidate
                    break
        role, role_font = "正文", font or self.font("fangsong")
        if level in LEVEL_FONTS and font is None:                 # 7.3.3 分层字体
            role_font = self.font(LEVEL_FONTS[level])
            role = f"{level}级标题" if level <= 2 else "正文"
        self.para(text, font=role_font, size=size or SIZE_3, bold=bool(bold),
                  align=align or "justify", first_line_chars=2.0,
                  space_before_pt=space_before_pt, role=role)

    def _table(self, item: dict[str, Any]) -> None:
        """第 8 章 横排表格：表格版式与正文一致。"""
        rows = item.get("rows") or []
        if not rows or not rows[0]:
            return
        table = self.doc.add_table(rows=len(rows), cols=len(rows[0]))
        table.style = "Table Grid"
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        for r_index, row in enumerate(rows):
            for c_index, value in enumerate(row):
                cell = table.cell(r_index, c_index)
                paragraph = cell.paragraphs[0]
                header_row = bool(item.get("header")) and r_index == 0
                paragraph.alignment = (WD_ALIGN_PARAGRAPH.CENTER if header_row
                                       else WD_ALIGN_PARAGRAPH.LEFT)
                _set_line_spacing(paragraph, line_pt=LINE_PT * 0.85)
                run = paragraph.add_run(str(value))
                set_run_font(run, self.font("fangsong"), SIZE_3, bold=header_row)
        self.used_pt += (len(rows) + 1) * LINE_PT
        self.plan.append({"role": "表格", "text": f"{len(rows)}行×{len(rows[0])}列"})

    def _attachment_note(self) -> None:
        """7.3.4 附件说明：正文下空一行左空二字，附件名称后不加标点。"""
        attachments = [str(a) for a in (self.spec.get("attachment_note") or [])]
        if not attachments:
            return
        if len(attachments) == 1:
            self.para(f"附件：{attachments[0]}", align="left", left_chars=2.0,
                      space_before_pt=LINE_PT, role="附件说明")
            return
        for index, name in enumerate(attachments):
            text = f"附件：{index + 1}. {name}" if index == 0 else f"{index + 1}. {name}"
            self.para(text, align="left", left_chars=5.0 if index else 2.0,
                      space_before_pt=LINE_PT if index == 0 else 0.0, role="附件说明")

    def _minutes_attendees(self) -> None:
        """10.3 纪要：出席 / 请假 / 列席名单，3 号黑体标签 + 3 号仿宋姓名。"""
        for key, label in (("attendees", "出席"), ("absent", "请假"), ("observers", "列席")):
            value = self.spec.get(key)
            if not value:
                continue
            paragraph = self.doc.add_paragraph()
            paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            _set_line_spacing(paragraph)
            _no_snap(paragraph)
            _set_char_indent(paragraph, SIZE_3, left_chars=5.0, first_line_chars=-3.0)
            if key == "attendees":
                paragraph.paragraph_format.space_before = Pt(LINE_PT)
            label_run = paragraph.add_run(f"{label}：")
            set_run_font(label_run, self.font("hei"), SIZE_3)
            body_run = paragraph.add_run(str(value))
            set_run_font(body_run, self.font("fangsong"), SIZE_3)
            self.used_pt += LINE_PT + (LINE_PT if key == "attendees" else 0.0)
            self.plan.append({"role": f"纪要{label}名单", "text": f"{label}：{value}",
                              "font": "黑体+仿宋", "size": SIZE_3, "left_chars": 5.0})

    def _signature_block(self) -> None:
        """7.3.5 发文机关署名、成文日期和印章（按“字”精确计算右空字数）。

        7.3.5.2 不加盖印章：署名右空二字，成文日期首字比署名首字右移二字；
                 成文日期长于署名时，成文日期右空二字，并相应增加署名右空字数。
        7.3.5.1 加盖印章：成文日期右空四字，署名以成文日期为准居中。
        """
        spec = self.spec
        signature = str(spec.get("signature") or "").strip()
        date = str(spec.get("date") or "").strip()
        duty = str(spec.get("signer_duty") or "").strip()
        if not (signature or date or duty):
            return

        if duty:            # 7.3.5.3 加盖签发人签名章：右空四字，签名章左空二字标职务
            self.blank(1)
            self.para(f"{duty}　{spec.get('signer_name', '')}".strip(), align="right",
                      right_chars=4.0, role="签发人职务/签名章")
            if date:
                self.para(date, align="right", right_chars=4.0, role="成文日期")
            return

        date_w, sig_w = text_width(date), text_width(signature)
        signature_r, date_r = 2.0, 2.0          # 右空字数（字）
        if spec.get("seal"):
            # 7.3.5.1 成文日期右空四字；署名以成文日期为准居中
            date_r = 4.0
            signature_r = max(2.0, date_r + (date_w - sig_w) / 2.0)
        elif date_w > sig_w:
            # 7.3.5.2 成文日期长于署名：日期右空二字，署名相应增加右空字数
            signature_r = 2.0 + (date_w - sig_w)
        else:
            # 署名右空二字；日期首字比署名首字右移二字
            signature_r = 2.0
            date_r = 2.0 + (sig_w - date_w) - 2.0
        self.blank(1)
        if signature:
            paragraph = self.para(signature, align="right", role="发文机关署名")
            _set_right_indent_exact(paragraph, signature_r * SIZE_3, SIZE_3)
            self.plan.append({"role": "发文机关署名", "text": signature,
                              "right_chars": round(signature_r, 2)})
        if date:
            paragraph = self.para(date, align="right", role="成文日期")
            _set_right_indent_exact(paragraph, date_r * SIZE_3, SIZE_3)
            self.plan.append({"role": "成文日期", "text": date,
                              "right_chars": round(date_r, 2)})

    # --------------------------------------------------------------- 附件
    def build_attachments(self) -> None:
        """7.3.7 附件：另面编排、在版记之前；“附件”及顺序号 3 号黑体顶格第一行。"""
        attachments = self.spec.get("attachments") or []
        for index, attachment in enumerate(attachments, start=1):
            if isinstance(attachment, str):
                attachment = {"title": attachment}
            number = "" if len(attachments) == 1 else str(index)
            self.para(f"附件{number}", font=self.font("hei"), size=SIZE_3, align="left",
                      role="附件标识", page_break_before=True)
            self.used_pt = LINE_PT                       # 另面起排，重新计行
            self.blank(1)                                # 附件标题居中编排在版心第三行
            if attachment.get("title"):
                self.para(attachment["title"], font=self.font("xbs"), size=SIZE_2,
                          align="center", role="附件标题")
            for text in attachment.get("body") or []:
                self._body_paragraph(str(text))
            if attachment.get("signature"):
                self.blank(1)
                self.para(attachment["signature"], align="right", right_chars=2.0,
                          role="附件署名")
            if attachment.get("date"):
                self.para(attachment["date"], align="right", right_chars=2.0,
                          role="附件成文日期")

    # --------------------------------------------------------------- 版记
    def build_version_record(self) -> None:
        """7.4 版记：抄送机关、印发机关和印发日期；首末粗线、中间细线。
        10.1 信函格式不加印发机关和印发日期、分隔线。"""
        spec = self.spec
        copy_to = str(spec.get("copy_to") or "").strip()
        main_to = str(spec.get("recipient_record") or
                      (spec.get("recipient") if spec.get("recipient_in_record") else "")
                      or "").strip()
        print_org = str(spec.get("print_org") or "").strip()
        print_date = str(spec.get("print_date") or "").strip()
        letter = self.fmt == "letter"
        if not letter:
            pass
        else:                                     # 信函格式：版记只有抄送等要素，无线
            print_org = print_date = ""

        blocks = [(label, text) for label, text in (("主送", main_to), ("抄送", copy_to)) if text]
        if not (blocks or print_org or print_date):
            return

        record_lines = 0
        for label, text in blocks:            # 4 号仿宋：首行左空一字、回行与冒号后首字对齐
            record_lines += count_lines_by_capacity(f"{label}：{text}",
                                                    EFFECTIVE_CHARS_4 - 2,
                                                    EFFECTIVE_CHARS_4 - 5)
        if print_org or print_date:
            record_lines += 1

        # 7.4.1 末条分隔线应与公文最后一面的版心下边缘重合。
        # Word 与 LibreOffice 的换行算法不同，靠“数行数”无法稳定沉底，
        # 因此默认把版记独立成一节（另起一页），并用一个精确行高的空段落把它压到版心底部；
        # 也可选择 same_page（紧接正文）或 auto（按行数估算沉底到当前页）。
        placement = str(spec.get("version_record_placement") or "new_page")
        self.content_lines = round(self.used_pt / LINE_PT, 2)
        spacer_lines = 0
        if placement == "new_page":
            self.doc.add_section(WD_SECTION.NEW_PAGE)
            # 版记单独成页：该页不编排页码（7.5 版记页不编排页码）
            self.record_only_sections.add(len(self.doc.sections) - 1)
            # 段高 = 版心高 - 版记高 - 少量安全余量（避免恰好占满时溢出到下一页）
            spacer_pt = CONTENT_H_MM * MM2PT - (record_lines + 0.2) * LINE_PT
            if spacer_pt > LINE_PT:
                self.para("", role="版记沉底", line_pt=spacer_pt)
        elif placement == "auto":
            used_on_page = (self.used_pt / LINE_PT) % LINES_PER_PAGE
            if LINES_PER_PAGE - used_on_page < record_lines + 2:
                used_on_page = 0.0                       # 本页排不下，版记另起一页
            spacer_lines = max(0, math.floor(LINES_PER_PAGE - used_on_page - record_lines))
            if spacer_lines:
                self.blank(spacer_lines, break_before=used_on_page == 0.0)

        for index, (label, text) in enumerate(blocks):
            # 7.4.2 抄送机关一般用 4 号仿宋体字，左右各空一字，回行与冒号后首字对齐
            self.para(f"{label}：{text}", align="justify", size=SIZE_4, left_chars=4.0,
                      first_line_chars=-3.0, role=f"{label}机关",
                      top_border=(RULE_THICK_PT if index == 0 else RULE_THIN_PT, "000000"))
        if print_org or print_date:
            paragraph = self.doc.add_paragraph()
            paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
            _set_line_spacing(paragraph)
            _no_snap(paragraph)
            _set_char_indent(paragraph, SIZE_4, left_chars=1.0, right_chars=1.0)
            position = Pt(CONTENT_W_MM * MM2PT - 1.0 * SIZE_4)
            paragraph.paragraph_format.tab_stops.add_tab_stop(position, WD_TAB_ALIGNMENT.RIGHT)
            run = paragraph.add_run(print_org)
            set_run_font(run, self.font("fangsong"), SIZE_4)
            run = paragraph.add_run("\t" + (f"{print_date}印发" if print_date else ""))
            set_run_font(run, self.font("fangsong"), SIZE_4)
            _set_border(paragraph,
                        top=(RULE_THIN_PT, "000000") if blocks else (RULE_THICK_PT, "000000"),
                        bottom=(RULE_THICK_PT, "000000"))
            self.used_pt += LINE_PT
            self.plan.append({"role": "印发机关和印发日期",
                              "text": f"{print_org}\t{print_date}", "font": "仿宋",
                              "size": SIZE_4})
        self.plan.append({"role": "版记", "spacer_lines": spacer_lines,
                          "placement": str(spec.get("version_record_placement") or "new_page"),
                          "text": f"主送={main_to or '无'};抄送={copy_to or '无'}"})

    # --------------------------------------------------------------- 页码
    def build_page_numbers(self) -> None:
        """7.5 页码：4 号半角宋体，单页码居右空一字、双页码居左空一字，
        数字左右各一条一字线，一字线上距版心下边缘 7mm。

        7.5 还规定：版记页前有空白页的，空白页和版记页均不编排页码。
        因此单独成页的版记不排页码（本页只有版记）。
        """
        spec = self.spec
        try:
            self.doc.settings.odd_and_even_pages_header_footer = True
        except Exception:  # noqa: BLE001 - 兼容老版本 python-docx
            pass
        for index, section in enumerate(self.doc.sections):
            numbering = bool(spec.get("page_number"))
            if index in self.record_only_sections:
                numbering = False           # 7.5 版记页不编排页码
            self._page_numbers_for(section, spec, numbering=numbering)

    def _page_numbers_for(self, section, spec: dict[str, Any], *,
                          numbering: bool = True) -> None:
        if self.fmt == "letter":
            # 10.1 首页不显示页码：首页页脚印“距下页边 20mm”的红色双线（上细下粗）
            section.different_first_page_header_footer = True
            footer = section.first_page_footer
            footer.is_linked_to_previous = False
            for index, thickness in enumerate((RULE_THIN_PT, RULE_HEADER_PT)):
                paragraph = (footer.paragraphs[0] if index == 0 and footer.paragraphs
                             else footer.add_paragraph())
                paragraph.text = ""
                _set_line_spacing(paragraph, 1.6)
                _set_border(paragraph, bottom=(thickness, "FF0000"),
                            line_width_pt=LETTER_RULE_W_MM * MM2PT)
        if not numbering:
            for footer in (section.footer, section.even_page_footer):
                footer.is_linked_to_previous = False
                for paragraph in list(footer.paragraphs):
                    for run in list(paragraph.runs):
                        run._element.getparent().remove(run._element)
            return
        for footer, right_aligned in ((section.footer, True),
                                      (section.even_page_footer, False)):
            footer.is_linked_to_previous = False
            paragraph = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
            paragraph.text = ""
            # 7.5 单页码居右空一字、双页码居左空一字
            paragraph.alignment = (WD_ALIGN_PARAGRAPH.RIGHT if right_aligned
                                   else WD_ALIGN_PARAGRAPH.LEFT)
            _set_line_spacing(paragraph, SIZE_4 * 1.3)
            _set_char_indent(paragraph, SIZE_4,
                             right_chars=1.0 if right_aligned else 0.0,
                             left_chars=0.0 if right_aligned else 1.0)
            for text in ("—", None, "—"):
                if text is None:
                    _add_field(paragraph, " PAGE ")
                    continue
                run = paragraph.add_run(text)
                set_run_font(run, self.font("song"), SIZE_4)

    # ---------------------------------------------------------------- 组装
    def build(self) -> Document:
        self.build_header()
        self.build_body()
        self.build_attachments()
        self.build_version_record()
        self.build_page_numbers()
        self.layout = self.geometry()
        return self.doc

    # ------------------------------------------------------------ 几何自检
    def geometry(self) -> dict[str, Any]:
        """算出全篇关键几何量（毫米／磅），供生成报告与校验器核对国标。

        这里是“不用渲染也能核对版式”的落点：生成报告里直接给出
        版心、天头、发文机关标志上边缘位置、红色分隔线位置、页码位置，
        并逐条标注是否符合 GB/T 9704—2012。
        """
        fmt = self.fmt
        header_lines = int(self.mark_gap.get("header_lines") or 0)
        trim_mm = float(self.mark_gap.get("top_trim_pt") or 0.0) / MM2PT
        # 直接读本节真实页边距，保证自检与实际落盘的 docx 一致（不要再另算一套）
        top_mm = self.doc.sections[0].top_margin.mm
        checks: list[dict[str, Any]] = []

        def check(name: str, actual: float, expected: float, unit: str = "mm",
                  tolerance: float = 0.5) -> None:
            checks.append({
                "item": name, "actual": round(actual, 3), "expected": expected,
                "unit": unit, "tolerance": tolerance,
                "result": "pass" if abs(actual - expected) <= tolerance else "fail",
            })

        geometry: dict[str, Any] = {
            "page_mm": {"width": PAGE_W_MM, "height": PAGE_H_MM},
            "content_mm": {"width": CONTENT_W_MM, "height": CONTENT_H_MM},
            "margins_mm": {"top": top_mm, "left": MARGIN_LEFT_MM,
                           "right": MARGIN_RIGHT_MM,
                           "bottom": PAGE_H_MM - top_mm - CONTENT_H_MM},
            "line_pt": round(LINE_PT, 3),
            "lines_per_page": LINES_PER_PAGE,
            "chars_per_line": CHARS_PER_LINE,
            "header_lines": header_lines,
            "format": fmt,
        }

        check("版心宽度", CONTENT_W_MM, 156.0)
        check("版心高度", CONTENT_H_MM, 225.0)
        # 天头：正常情况下 37mm；信函格式的红头要求“距上页边 30mm”，
        # 等于把标志排到版心之上，渲染器会相应地压掉天头，故按 37mm+标定偏移核对。
        expected_top = MARGIN_TOP_MM - trim_mm
        if fmt == "letter" and trim_mm <= 0.01:
            expected_top = MARGIN_TOP_MM + LETTER_MARK_OFFSET_MM
        check("天头（上白边）", top_mm, expected_top,
              tolerance=3.0 if fmt == "letter" else 0.5)
        check("订口（左白边）", MARGIN_LEFT_MM, 28.0)

        if fmt != "no_header":
            gap = dict(self.mark_gap)
            if gap:
                expected_offset = (COMMAND_MARK_OFFSET_MM if fmt == "command"
                                   else LETTER_MARK_OFFSET_MM if fmt == "letter"
                                   else MARK_OFFSET_MM)
                mark_top_content = gap.get("mark_top_from_content_mm")
                if mark_top_content is not None:
                    # 信函格式的目标是“距上页边 30mm”，换算到版心坐标系时含实测标定偏差，
                    # 这里对它的容差放宽到 2mm；其余版式仍按 0.6mm 严核。
                    check("发文机关标志上边缘至版心上边缘", mark_top_content,
                          expected_offset,
                          tolerance=2.0 if fmt == "letter"
                          else (0.6 if gap.get("mode") == "glyph" else 1.5))
                geometry["issuer_mark"] = gap
                if mark_top_content is not None:
                    geometry["issuer_mark"]["top_from_page_mm"] = round(
                        top_mm + mark_top_content, 3)
                geometry["issuer_mark"]["rule_from_page_mm"] = round(
                    top_mm + self.header_height_mm(), 3)

        geometry["checks"] = checks
        geometry["failed"] = [c["item"] for c in checks if c["result"] == "fail"]
        return geometry

    def header_height_mm(self) -> float:
        """版头（红色分隔线以下为界）占版心的总高度，毫米。"""
        total_pt = 0.0
        for item in self.plan:
            if item.get("role") == "版头红色分隔线":
                total_pt += float(item.get("space_before_pt") or 0.0)
                return total_pt / MM2PT
            if item.get("role") in {"发文机关标志", "发文字号", "发文字号/签发人",
                                    "份号", "密级和保密期限", "紧急程度"}:
                total_pt += float(item.get("space_before_pt") or 0.0) + LINE_PT
        return total_pt / MM2PT

    def report(self) -> dict[str, Any]:
        return {
            "doc_type": self.spec.get("doc_type") or "",
            "format": self.fmt,
            "fonts": self.fonts.as_dict(),
            "font_metrics": {role: metrics_for(self.fonts.resolve(role)).source
                             for role in ("xbs", "fangsong", "hei", "kai", "song")},
            "warnings": list(self.fonts.warnings),
            "content_lines_before_record": self.content_lines,
            "lines_estimated": round(self.used_pt / LINE_PT, 2),
            "elements": len(self.plan),
            "layout": self.layout,
        }


def load_spec(path: str) -> dict[str, Any]:
    # utf-8-sig：兼容 Windows 记事本/PowerShell 写出的带 BOM 的 JSON
    with open(path, "r", encoding="utf-8-sig") as handle:
        return json.load(handle)


# --------------------------------------------------------------------------
# PDF 导出：交付物只有 .docx + .pdf，两份文件同名同目录
# --------------------------------------------------------------------------
# DSH 随运行环境打包的 LibreOffice Kit（优先使用；不搜索系统 LibreOffice）
BUNDLED_NODE = r"D:\AI\DSH\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"
BUNDLED_LO_CLI = (r"D:\AI\DSH\resources\app.asar.unpacked\dsh\node_modules"
                  r"\@deepseek-ai\libreoffice-kit\lib\cli.js")


def _first_existing(*candidates: str) -> str | None:
    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            return candidate
    return None


def find_libreoffice_kit() -> tuple[str, str] | None:
    """找打包的 LibreOffice Kit：返回 (node.exe, cli.js)，找不到返回 None。"""
    node = _first_existing(
        os.environ.get("DSH_NODE", ""), os.environ.get("DSH_NODE_PATH", ""), BUNDLED_NODE)
    cli = _first_existing(
        os.environ.get("DSH_LIBREOFFICE_CLI", ""), BUNDLED_LO_CLI)
    if node and cli:
        return node, cli
    return None


def find_system_soffice() -> str | None:
    """系统安装的 LibreOffice（仅在明确允许时使用）。"""
    override = os.environ.get("OFFICIAL_DOC_SOFFICE", "")
    if override and os.path.isfile(override):
        return override
    return _first_existing(
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
        "/Applications/LibreOffice.app/Contents/MacOS/soffice",
        "/usr/bin/soffice", "/usr/local/bin/soffice", "/usr/bin/libreoffice",
    ) or shutil.which("soffice") or shutil.which("libreoffice")


def _convert_with_kit(node: str, cli: str, docx_path: str, pdf_path: str) -> None:
    def run() -> subprocess.CompletedProcess:
        return subprocess.run([node, cli, "convert", "--input", docx_path,
                               "--output", pdf_path],
                              capture_output=True, timeout=300, check=False,
                              encoding="utf-8", errors="replace")

    if os.path.exists(pdf_path):                 # 转换工具不会覆盖已存在的文件
        os.remove(pdf_path)
    result = run()
    if result.returncode != 0 or not os.path.isfile(pdf_path):
        # 并发或残留文件导致 EEXIST 时，清掉再来一次
        if os.path.exists(pdf_path):
            try:
                os.remove(pdf_path)
            except OSError:
                pass
        result = run()
    if result.returncode != 0 or not os.path.isfile(pdf_path):
        detail = (result.stderr or result.stdout or "").strip().replace("\n", " ")
        raise SpecError(f"LibreOffice Kit 导出 PDF 失败：{detail[:300]}")


def _convert_with_soffice(soffice: str, docx_path: str, pdf_path: str) -> None:
    out_dir = os.path.dirname(pdf_path) or "."
    expected = os.path.join(out_dir, os.path.splitext(os.path.basename(docx_path))[0] + ".pdf")
    if os.path.exists(expected):
        os.remove(expected)
    command = [soffice, "--headless", "--norestore", "--convert-to", "pdf",
               "--outdir", out_dir, docx_path]
    result = subprocess.run(command, capture_output=True, timeout=300, check=False,
                            encoding="utf-8", errors="replace")
    if not os.path.isfile(expected):
        detail = (result.stderr or result.stdout or "").strip().replace("\n", " ")
        raise SpecError(f"LibreOffice 未能生成 PDF：{detail[:300]}")
    if os.path.abspath(expected) != pdf_path:
        os.replace(expected, pdf_path)


def export_pdf(docx_path: str, pdf_path: str | None = None,
               allow_system_soffice: bool = False) -> str:
    """把 DOCX 转成 PDF；返回 PDF 路径，失败时抛 SpecError 并带上排查提示。

    默认只用随环境打包的 LibreOffice Kit；``allow_system_soffice=True`` 或设置环境变量
    ``OFFICIAL_DOC_USE_SYSTEM_SOFFICE=1`` 时才回退到系统安装的 LibreOffice。
    """
    docx_path = os.path.abspath(docx_path)
    if not os.path.isfile(docx_path):
        raise SpecError(f"找不到待转换的 DOCX：{docx_path}")
    pdf_path = os.path.abspath(pdf_path) if pdf_path else os.path.splitext(docx_path)[0] + ".pdf"
    os.makedirs(os.path.dirname(pdf_path) or ".", exist_ok=True)

    kit = find_libreoffice_kit()
    if kit:
        _convert_with_kit(kit[0], kit[1], docx_path, pdf_path)
        return pdf_path

    use_system = allow_system_soffice or \
        os.environ.get("OFFICIAL_DOC_USE_SYSTEM_SOFFICE") in {"1", "true", "True"}
    if use_system:
        soffice = find_system_soffice()
        if soffice:
            _convert_with_soffice(soffice, docx_path, pdf_path)
            return pdf_path
    if os.path.exists(pdf_path):
        # 转换失败时不留半成品，保持“要么两份、要么没有”
        try:
            os.remove(pdf_path)
        except OSError:
            pass

    raise SpecError(
        "未找到可用的 LibreOffice：默认只使用打包的 LibreOffice Kit。请用 --node/--libreoffice-cli "
        "指定 Kit 路径，或设置环境变量 DSH_LIBREOFFICE_CLI；确实要改用系统 LibreOffice 时，"
        "加 --soffice 路径或设置 OFFICIAL_DOC_USE_SYSTEM_SOFFICE=1。")


def build_from_spec(spec: dict[str, Any], resolver: FontResolver | None = None):
    builder = GongwenBuilder(spec, resolver)
    return builder.build(), builder


OUTPUT_FORMATS = ("word", "pdf", "both")
OUTPUT_FORMAT_LABELS = {"word": "Word（.docx）", "pdf": "PDF（.pdf）", "both": "Word + PDF（两份）"}


def normalize_output_format(value: str | None) -> str:
    """把用户给的输出格式说法归一成 word / pdf / both；缺省或非法都抛错（强制询问）。"""
    if value is None or str(value).strip() == "":
        raise SpecError(
            "未指定输出格式：必须先问用户要 Word、PDF，还是两个都要，再生成。"
            "（命令行用 --output-format word|pdf|both）")
    text = str(value).strip().lower().replace(" ", "")
    table = {
        "word": "word", "docx": "word", "doc": "word", "w": "word",
        "文档": "word", "word文档": "word", "只word": "word", "wordonly": "word",
        "pdf": "pdf", "p": "pdf", "只pdf": "pdf", "pdfonly": "pdf",
        "both": "both", "all": "both", "two": "both", "两个": "both", "都要": "both",
        "两个都要": "both", "两份": "both", "word+pdf": "both", "pdf+word": "both",
        "word和pdf": "both", "pdf和word": "both",
    }
    if text not in table:
        raise SpecError(f"输出格式只能是 word / pdf / both，收到的是“{value}”")
    return table[text]


def generate(spec: dict[str, Any], output: str, resolver: FontResolver | None = None,
             plan_path: str | None = None, pdf: bool | None = None,
             pdf_path: str | None = None, allow_system_soffice: bool = False,
             output_format: str | None = None) -> dict[str, Any]:
    """生成公文并返回报告。

    **输出格式必填**：``output_format`` 取 ``word``／``pdf``／``both``，缺省时回落到要素里的
    ``output_format``，两者都没有就抛 :class:`SpecError`（强制先问用户要哪种）。

    * ``word``：只产出 ``output``（.docx）；
    * ``pdf``：只产出同名 .pdf，先写临时 docx 再转换，交付目录里不留 docx；
    * ``both``：产出 .docx 与同名 .pdf 两份。

    ``plan_path`` 仅在显式要求时才写（内部规划，不作为交付物）。
    """
    if output_format is None:
        output_format = spec.get("output_format")
    if output_format is None and pdf is not None:
        # 兼容旧写法：--pdf → both，--no-pdf → word
        output_format = "both" if pdf else "word"
    chosen = normalize_output_format(output_format)

    document, builder = build_from_spec(spec, resolver)
    report = builder.report()
    report["output_format"] = chosen
    report["deliverables"] = []

    if chosen == "pdf":
        # 只交 PDF：docx 只作中间产物，转完就删
        with tempfile.TemporaryDirectory(prefix="gongwen_pdf_") as temp_dir:
            temp_docx = os.path.join(temp_dir, os.path.basename(output) or "gongwen.docx")
            document.save(temp_docx)
            target = pdf_path or os.path.splitext(os.path.abspath(output))[0] + ".pdf"
            pdf_file = export_pdf(temp_docx, target,
                                  allow_system_soffice=allow_system_soffice)
        report["pdf"] = pdf_file
        report["deliverables"].append(pdf_file)
    else:
        document.save(output)
        report["output"] = os.path.abspath(output)
        report["deliverables"].append(os.path.abspath(output))
        if chosen == "both":
            pdf_file = export_pdf(output, pdf_path,
                                  allow_system_soffice=allow_system_soffice)
            report["pdf"] = pdf_file
            report["deliverables"].append(pdf_file)

    if plan_path:
        with open(plan_path, "w", encoding="utf-8") as handle:
            json.dump(builder.plan, handle, ensure_ascii=False, indent=2)
        report["plan"] = os.path.abspath(plan_path)
    return report



# --------------------------------------------------------------------------
# 必答 / 可选要素清单（原 scripts/generate_official_doc.py，功能不变）
#   missing_required / ask_checklist / build_spec —— 对应 --needs / --ask
# --------------------------------------------------------------------------
# 三类必填要素：任何文种都要 / 上行文要 / 面向社会公布件不需要主送机关
BASE_REQUIRED = ("doc_type", "issuer", "title", "body", "date", "output_format")


UPWARD_ONLY = ("signers",)


FIELD_LABELS = {
    "doc_type": "文种（15 种法定文种之一）",
    "issuer": "发文机关全称或规范化简称",
    "issuer_mark": "发文机关标志（红头文字）",
    "title": "公文标题",
    "title_lines": "标题回行",
    "recipient": "主送机关（末尾全角冒号）",
    "body": "正文内容",
    "date": "成文日期",
    "signers": "签发人姓名（上行文必填）",
    "doc_number": "发文字号",
    "signature": "发文机关署名",
    "seal": "是否加盖印章",
    "secrecy": "密级和保密期限",
    "urgency": "紧急程度",
    "copy_to": "抄送机关",
    "print_org": "印发机关",
    "print_date": "印发日期",
    "attachment_note": "附件说明",
    "attachments": "附件正文",
    "note": "附注",
    "output_format": "交付格式（Word / PDF / 两个都要）",
}


def missing_required(spec: dict[str, Any]) -> list[str]:
    """列出还缺的必填要素（供技能“一次问全”时使用）。"""
    doc_type = str(spec.get("doc_type") or "").strip()
    missing = [field for field in BASE_REQUIRED if not spec.get(field)]
    if doc_type and doc_type not in NO_RECIPIENT_TYPES and not spec.get("recipient") \
            and not spec.get("recipient_in_record"):
        missing.append("recipient")
    if doc_type in UPWARD_TYPES and not spec.get("signers"):
        missing.extend(UPWARD_ONLY)
    if not spec.get("signature") and doc_type not in NO_RECIPIENT_TYPES:
        missing.append("signature")
    return missing


# 必填项要一次问全（用户一轮答完）；可选项只提示“有就给”，不阻塞生成
REQUIRED_ASKS = [
    ("output_format", "交付格式（**必须问**）：Word（.docx）、PDF 还是两个都要？"
                      "生成前一定要先问清，没问出来不生成"),
    ("doc_type", "文种：只能是 15 种法定文种之一（用户说的事项先归到某个文种，别用非法文种名）"),
    ("issuer", "发文机关：全称或规范化简称，例如“XX市数据局”"),
    ("recipient", "主送机关：报给谁，例如“XX市人民政府：”（公告、通告、公报、决议、纪要可不写）"),
    ("title", "标题／事由：写什么事，例如“关于开展2026年度安全检查工作的通知”"),
    ("body", "正文要点：要求、措施、时间、范围、数据；有草稿、会议材料、原文件请直接给原文"),
    ("date", "成文日期：例如“2026年3月13日”，月、日不编虚位（写“今天”也可以，我按当天填）"),
    ("signers", "签发人姓名：请示、报告等上行文必填，可多个人名"),
    ("signature", "发文机关署名：落款怎么署，例如“XX市数据局”"),
]


OPTIONAL_ASKS = [
    ("doc_number", "发文字号：如“XX数据〔2026〕7号”，没有我不加"),
    ("secrecy", "密级和保密期限：如“秘密★1年”"),
    ("urgency", "紧急程度：如“特急”“加急”"),
    ("copy_to", "抄送机关：如“市委办公室，市人大常委会办公室。”"),
    ("print_org", "印发机关：如“XX市数据局办公室”"),
    ("print_date", "印发日期：如“2026年3月14日”"),
    ("attachment_note", "附件说明：正文下方的“附件：1. ×××”，有附件才写"),
    ("attachments", "附件正文：附件全文，我会另面编排在版记之前"),
    ("note", "附注：如“此件公开发布”"),
    ("seal", "是否加盖印章：加盖时成文日期右空四字、署名以日期为准居中"),
    ("issuer_mark", "发文机关标志原文：红头上那行字，默认“机关名称＋文件”"),
    ("title_lines", "标题回行：需要按梯形／菱形人工断行时给我每一行文字"),
]


def ask_checklist(spec: dict[str, Any]) -> dict[str, Any]:
    """生成“一次问全”的清单：必填缺项 + 可选项提示。"""
    doc_type = str(spec.get("doc_type") or "").strip()
    missing = missing_required(spec)
    required = [(field, hint) for field, hint in REQUIRED_ASKS
                if field in missing or (field == "recipient" and "recipient" in missing)]
    if not doc_type:
        required.insert(0, ("doc_type", REQUIRED_ASKS[0][1]))
    seen = set()
    required_items = []
    for field, hint in required:
        if field in seen:
            continue
        seen.add(field)
        required_items.append({"field": field,
                               "label": FIELD_LABELS.get(field, field), "hint": hint})
    return {
        "doc_type": doc_type,
        "must_ask_format_first": {
            "field": "output_format",
            "question": "要 Word（.docx）、PDF，还是两个都要？",
            "options": list(OUTPUT_FORMATS),
        },
        "must_answer_all_at_once": required_items,
        "optional_if_available": [
            {"field": field, "label": FIELD_LABELS.get(field, field), "hint": hint}
            for field, hint in OPTIONAL_ASKS
            if not spec.get(field)
        ],
        "note": "必填项必须在同一次提问里全部列出，请用户一轮答完；"
                "可选要素一并提示“有就提供，没有我就不加”，不要阻塞、也不要事后自行补全。",
    }


def _read_body_file(path: str) -> list[str]:
    with open(path, "r", encoding="utf-8-sig") as handle:      # 兼容 BOM
        return [line.rstrip("\n") for line in handle]


def build_spec(args) -> dict[str, Any]:
    spec: dict[str, Any] = {}
    if args.spec:
        spec.update(load_spec(args.spec))
    if args.type:
        spec["doc_type"] = args.type
    for field in ("title", "issuer", "issuer_mark", "recipient", "doc_number", "date",
                  "signature", "print_org", "print_date", "copy_to", "note", "secrecy",
                  "urgency", "format", "mark_position"):
        value = getattr(args, field, None)
        if value:
            spec[field] = value
    body: list[str] = []
    if args.body_file:
        body.extend(_read_body_file(args.body_file))
    if args.body:
        body.extend(args.body)
    if body:
        spec["body"] = body
    if args.signers:
        spec["signers"] = [s.strip() for s in
                           args.signers.replace("，", "、").replace(",", "、").split("、")
                           if s.strip()]
    if args.attachment:
        spec["attachment_note"] = list(args.attachment)
    if args.seal:
        spec["seal"] = True
    return spec


# --------------------------------------------------------------------------
# 要素层 + 版式层校验（原 scripts/validate.py，功能不变）
#   AuditReport / validate_spec / validate_docx_layer
# --------------------------------------------------------------------------
# 无主送机关（面向社会公开发布或会议审议通过）的文种
NO_RECIPIENT_TYPES = {"公告", "通告", "公报", "决议", "纪要"}


# 一般不加盖印章、可不标署名的文种
NO_SIGNATURE_TYPES = {"公报", "纪要", "决议", "公告", "通告"}


# 需要签发人的文种（《条例》第十七条：上行文应当标注签发人姓名）
REQUIRE_SIGNER_TYPES = {"请示", "报告"}


BAD_PHRASES = [
    (r"妥否[，,]\s*请批复", "请示结语应为“妥否，请批示。”"),
    (r"特此申请", "公文中不用“特此申请”，请示用“妥否，请批示。”或“以上请示，请予批复。”"),
    (r"请领导审阅并批准", "请示结语不用口语化表述，应写“妥否，请批示。”"),
    (r"大约左右|约左右", "“大约”与“左右”重复"),
    (r"亲自莅临|亲临莅临", "“莅临”已含亲自之意"),
    (r"截止目前|截止到目前", "应用“截至目前”"),
    (r"进一步加强力度", "搭配不当，应为“进一步加大力度”"),
    (r"进行.{0,4}工作的情况", "“进行……工作”属于冗余表达，宜直接用动词"),
    (r"下面|接下来|大家", "公文中不使用口语化表述"),
    (r"OK|ok|搞定|点赞|给力", "公文中不使用网络用语"),
    (r"请示报告", "不得混用文种，请示与报告是两个独立文种"),
    (r"批示为盼|批复为盼", "结语不规范"),
]


NUMBER_PATTERNS = [
    (r"〔\d{2}〕", "发文字号年份应标全称（4 位阿拉伯数字），如〔2026〕"),
    (r"第\d+号", "发文顺序号不加“第”字"),
    (r"\[\d{4}\]", "发文字号年份应用六角括号〔〕，不用方括号"),
    (r"0\d+号", "发文顺序号不编虚位（1 不编为 01）"),
]


PUNCT_PATTERNS = [
    (r"^关于.+[。．.]$", "公文标题末尾不加标点符号"),
    (r"附件：.*[，。；]$", "附件说明中的附件名称后不加标点符号"),
]


class AuditReport:
    """校验结果收集器。"""

    def __init__(self) -> None:
        self.items: list[dict[str, str]] = []

    def error(self, code: str, message: str) -> None:
        self.items.append({"level": "error", "code": code, "message": message})

    def warn(self, code: str, message: str) -> None:
        self.items.append({"level": "warning", "code": code, "message": message})

    def info(self, code: str, message: str) -> None:
        self.items.append({"level": "info", "code": code, "message": message})

    @property
    def errors(self) -> list[dict[str, str]]:
        return [i for i in self.items if i["level"] == "error"]

    @property
    def warnings(self) -> list[dict[str, str]]:
        return [i for i in self.items if i["level"] == "warning"]

    def render(self) -> str:
        lines = []
        icon = {"error": "[错误]", "warning": "[提醒]", "info": "[提示]"}
        for item in self.items:
            lines.append(f"{icon[item['level']]} [{item['code']}] {item['message']}")
        lines.append(f"\n合计：{len(self.errors)} 个错误，{len(self.warnings)} 个提醒，"
                     f"{len(self.items) - len(self.errors) - len(self.warnings)} 条提示")
        return "\n".join(lines)


# --------------------------------------------------------------------------
# 要素层校验
# --------------------------------------------------------------------------
def validate_spec(spec: dict[str, Any], report: AuditReport) -> None:
    doc_type = str(spec.get("doc_type") or "").strip()
    if not doc_type:
        report.warn("T001", "未填写 doc_type（文种），将无法校验结语与行文方向")
    elif doc_type not in DOC_TYPES:
        report.error("T002", f"“{doc_type}”不是 15 种法定文种之一：{'、'.join(DOC_TYPES)}")

    fmt = str(spec.get("format") or "standard")
    if fmt not in {"standard", "no_header", "letter", "command", "minutes"}:
        report.error("T003", f"format 取值不合法：{fmt}")

    title = str(spec.get("title") or "").strip()
    command_format = fmt == "command"
    if not title and not command_format:
        report.warn("E001", "缺少公文标题")
    elif title:
        if len(title) > 40:
            report.warn("E002", f"标题较长（{len(title)} 字），请确认已用 title_lines 控制回行")
        if doc_type and doc_type not in title:
            report.warn("E003", f"标题未包含文种“{doc_type}”；公文标题一般由“发文机关+事由+文种”组成")
        for pattern, message in PUNCT_PATTERNS:
            if re.search(pattern, title):
                report.error("E004", message)
        if re.search(r"关于.*关于", title):
            report.warn("E005", "标题中出现多个“关于”，请精简事由")

    recipient = str(spec.get("recipient") or "").strip()
    if not recipient and not spec.get("recipient_in_record"):
        if doc_type in NO_RECIPIENT_TYPES or fmt in {"command", "minutes", "letter", "no_header"}:
            report.info("E006", "本版式/文种可不标注主送机关")
        else:
            report.warn("E007", "缺少主送机关；如主送机关过多，可用 recipient_in_record 移至版记")
    elif recipient and not recipient.endswith("："):
        report.error("E008", "主送机关最后一个机关名称后应标全角冒号“：”")
    if recipient and recipient.endswith(":") and not recipient.endswith("："):
        report.error("E009", "主送机关冒号应为全角“：”")

    if not spec.get("body"):
        report.error("E010", "正文（body）不能为空")
    if not spec.get("title") and fmt != "command":
        report.warn("E011", "未提供标题")

    signature = str(spec.get("signature") or "").strip()
    date = str(spec.get("date") or "").strip()
    if not signature and doc_type not in NO_SIGNATURE_TYPES and not spec.get("signer_duty"):
        report.warn("E012", "缺少发文机关署名")
    if not date and doc_type not in {"公报", "纪要"}:
        report.warn("E013", "缺少成文日期")
    if date and not re.fullmatch(r"\d{4}年\d{1,2}月\d{1,2}日", date):
        report.error("E014", f"成文日期应为“2026年3月13日”形式且月、日不编虚位，当前为“{date}”")

    doc_number = str(spec.get("doc_number") or "").strip()
    if doc_number:
        if not re.fullmatch(r"[^〔〕\s]+〔\d{4}〕\d+号", doc_number):
            report.error("E015", f"发文字号格式不正确：{doc_number}（应为“机关代字〔年份〕序号号”）")
        for pattern, message in NUMBER_PATTERNS:
            if re.search(pattern, doc_number):
                report.error("E016", message)
    else:
        report.info("E017", "未标注发文字号（公告、通告、纪要等可以只有标题）")

    signers = spec.get("signers") or []
    if doc_type in REQUIRE_SIGNER_TYPES and not signers:
        report.error("E018", f"{doc_type}属上行文，应当标注签发人（signers）")
    elif doc_type in UPWARD_TYPES and not signers:
        report.warn("E019", f"{doc_type}如按上行文报送，应标注签发人")
    if signers and len(signers) > 4:
        report.info("E020", f"签发人较多（{len(signers)} 人），将按每行两人均匀编排")

    copy_to = str(spec.get("copy_to") or "").strip()
    if copy_to and not copy_to.endswith("。"):
        report.warn("E021", "抄送机关最后一个机关名称后应标句号")

    print_org = str(spec.get("print_org") or "").strip()
    print_date = str(spec.get("print_date") or "").strip()
    if print_org and not print_date:
        report.warn("E022", "有印发机关但缺少印发日期")
    if print_date and date:
        if _date_key(print_date) < _date_key(date):
            report.error("E023", f"印发日期（{print_date}）早于成文日期（{date}）")

    notes = spec.get("attachment_note") or []
    attachments = spec.get("attachments") or []
    if attachments and not notes:
        report.warn("E024", "有附件正文但缺少附件说明（attachment_note）")
    if notes and attachments and len(notes) != len(attachments):
        report.warn("E025", f"附件说明 {len(notes)} 项与附件正文 {len(attachments)} 项数量不一致")
    for name in notes:
        if re.search(r"[，。；、]$", str(name)):
            report.error("E026", f"附件名称后不加标点符号：{name}")

    if spec.get("seal") and spec.get("signer_duty"):
        report.warn("E027", "同时设置了印章（seal）与签发人签名章（signer_duty），请确认编排方式")

    _check_body(spec, doc_type, report)


def _date_key(value: str) -> tuple[int, int, int]:
    match = re.match(r"(\d{4})年(\d{1,2})月(\d{1,2})日", str(value))
    return (int(match.group(1)), int(match.group(2)), int(match.group(3))) if match else (0, 0, 0)


def _paragraph_texts(spec: dict[str, Any]) -> list[str]:
    texts = []
    for item in spec.get("body") or []:
        if isinstance(item, str):
            texts.append(item)
        elif isinstance(item, dict) and item.get("type", "para") == "para":
            texts.append(str(item.get("text") or ""))
    return [t for t in texts if t]


def _check_body(spec: dict[str, Any], doc_type: str, report: AuditReport) -> None:
    texts = _paragraph_texts(spec)
    if not texts:
        return
    joined = "\n".join(texts)

    # 层次序数连续性（GB/T 9704—2012 7.3.3）
    _check_sequence(texts, r"^([一二三四五六七八九十]+)、", "一、二、三", report)
    _check_sequence(texts, r"^[（(]([一二三四五六七八九十]+)[）)]", "（一）（二）（三）", report)
    _check_sequence(texts, r"^(\d+)[.．]", "1. 2. 3.", report, numeric=True)

    # 结语与文种匹配
    closings = CLOSING_WORDS.get(doc_type, [])
    tail = texts[-1]
    looks_like_closing = tail.endswith(("。", "！")) and (
        tail in COMMON_CLOSINGS or tail in closings or "请" in tail or "特此" in tail)
    if looks_like_closing:
        allowed = set(closings) | COMMON_CLOSINGS
        if tail not in allowed:
            report.warn("L001", f"结尾语“{tail}”不在{doc_type or '该文种'}常用结语之列；"
                                f"建议使用：{'、'.join(closings) or '按文种规范撰写'}")
    elif closings:
        report.warn("L002", f"{doc_type}一般应有规范结语，如：{'、'.join(closings)}")

    if doc_type == "报告" and re.search(r"请批示|请批准|请予批复|妥否|请审批", joined):
        report.error("L003", "报告中不得夹带请示事项（不得出现“请批示/请批准/妥否”等请示性表述）")
    if doc_type == "请示":
        if len(re.findall(r"^[一二三四五六七八九十]+、", joined, re.M)) > 3:
            report.warn("L004", "请示应当一文一事，事项较多时建议拆分或改为报告")
        if "特此报告" in joined:
            report.error("L005", "请示不得使用“特此报告”结语")
    if doc_type == "通知" and "请予研究函复" in joined:
        report.warn("L006", "“请予研究函复”是函的结语，通知不宜使用")
    if doc_type == "函" and re.search(r"必须|责成|限期整改", joined):
        report.warn("L007", "函用于不相隶属机关商洽工作，语气应商量，不宜使用命令性表述")

    # 公文语言禁忌
    for pattern, message in BAD_PHRASES:
        if re.search(pattern, joined):
            report.error("L008", f"{message}（匹配“{pattern}”）")

    # 标点与数字
    for pattern, message in PUNCT_PATTERNS:
        for text in texts:
            if re.search(pattern, text):
                report.error("L009", f"{message}：{text[:20]}…")
    if re.search(r"[（(]\s*[）)]", joined):
        report.warn("L010", "出现空括号")
    if re.search(r"[。；，]{2,}", joined):
        report.warn("L011", "出现连续标点")


def _check_sequence(texts: Sequence[str], pattern: str, label: str, report: AuditReport,
                    numeric: bool = False) -> None:
    """检查层次序数是否从 1 开始且连续。"""
    order = "一二三四五六七八九十"
    found = []
    for text in texts:
        match = re.match(pattern, text)
        if not match:
            continue
        token = match.group(1)
        value = int(token) if numeric else order.index(token) + 1 if token in order else 0
        found.append(value)
    if not found:
        return
    seen: list[int] = []
    for value in found:
        if value in seen:
            seen = seen[: seen.index(value) + 1]      # 进入下一级，重新计数
            continue
        seen.append(value)
    expected = list(range(1, len(seen) + 1))
    if seen != expected:
        report.warn("L012", f"层次序数不连续：{label} 实际为 {seen}，应为 {expected}")


# --------------------------------------------------------------------------
# 版式层校验（DOCX）
# --------------------------------------------------------------------------
def validate_docx_layer(path: str, spec: dict[str, Any], report: AuditReport) -> None:
    from docx import Document
    from docx.oxml.ns import qn
    from docx.shared import Mm, Pt

    document = Document(path)
    section = document.sections[0]

    def near(value: float, expected: float, tolerance: float = 0.6) -> bool:
        return abs(value - expected) <= tolerance

    # 10.1 信函格式：发文机关标志上边缘至上页边 30mm，下方红色双线距下页边 20mm
    letter = str(spec.get("format") or "standard") == "letter"
    checks = [
        ("页面宽度", section.page_width.mm, 210.0),
        ("页面高度", section.page_height.mm, 297.0),
        ("天头（上白边）", section.top_margin.mm, 30.0 if letter else 37.0),
        ("订口（左白边）", section.left_margin.mm, 28.0),
        ("下白边", section.bottom_margin.mm, 35.0),
        ("右白边", section.right_margin.mm, 26.0),
    ]
    for name, actual, expected in checks:
        if not near(actual, expected):
            report.error("D001", f"{name} {actual:.1f}mm 不符合 GB/T 9704—2012（应为 {expected}mm）")
    footer_expect = 20.0 if letter else 28.0
    if section.footer_distance.mm and not near(section.footer_distance.mm, footer_expect, 1.5):
        if letter:
            report.warn("D002", f"页脚距边界 {section.footer_distance.mm:.1f}mm，"
                                f"信函格式红色双线应距下页边 20mm")
        else:
            report.warn("D002", f"页脚距边界 {section.footer_distance.mm:.1f}mm，"
                                f"页码一字线应距版心下边缘 7mm（即页脚距边界约 28mm）")

    grid = section._sectPr.find(qn("w:docGrid"))
    if grid is None:
        report.warn("D003", "未设置文档网格（w:docGrid），Word 中每页行数可能偏离 22 行")
    elif not near(int(grid.get(qn("w:linePitch"), 0)) / 20.0, LINE_PT, 0.6):
        report.warn("D004", f"文档网格行距 {int(grid.get(qn('w:linePitch'), 0)) / 20:.1f}pt "
                            f"与固定行距 {LINE_PT:.2f}pt 不一致")

    allowed_fonts = {"仿宋_GB2312", "仿宋", "FangSong", "FangSong_GB2312", "STFangsong",
                     "黑体", "SimHei", "楷体_GB2312", "楷体", "KaiTi", "KaiTi_GB2312",
                     "STKaiti", "方正小标宋_GBK", "方正小标宋简体", "FZXiaoBiaoSong-B05S",
                     "华文中宋", "STZhongsong", "宋体", "SimSun", "NSimSun", "新宋体"}
    title = str(spec.get("title") or "").strip()
    recipient = str(spec.get("recipient") or "").strip()
    copy_to = str(spec.get("copy_to") or "").strip()
    seen_roles = set()
    body_fonts: set[str] = set()

    for paragraph in document.paragraphs:
        text = paragraph.text.strip()
        ppr = paragraph._p.find(qn("w:pPr"))
        spacing = ppr.find(qn("w:spacing")) if ppr is not None else None
        if spacing is not None and text:
            rule = spacing.get(qn("w:lineRule"))
            line = spacing.get(qn("w:line"))
            if rule == "exact" and line and not near(int(line) / 20.0, LINE_PT, 0.7):
                report.warn("D005", f"段落“{text[:12]}”固定行距 "
                                    f"{int(line) / 20:.1f}pt，与 22 行/页所需的 "
                                    f"{LINE_PT:.2f}pt 不一致")
        ind = ppr.find(qn("w:ind")) if ppr is not None else None
        for run in paragraph.runs:
            rpr = run._element.find(qn("w:rPr"))
            rfonts = rpr.find(qn("w:rFonts")) if rpr is not None else None
            font = rfonts.get(qn("w:eastAsia")) if rfonts is not None else None
            size = run.font.size.pt if run.font.size else None
            if not (run.text or "").strip():
                continue
            if font and font not in allowed_fonts:
                report.warn("D006", f"段落“{text[:12]}”使用了非公文字体“{font}”")
            if size is not None and size not in {14.0, 16.0, 22.0, 26.0}:
                report.warn("D007", f"段落“{text[:12]}”字号 {size}pt 不在公文常用字号"
                                    f"（三号 16pt／二号 22pt／四号 14pt）之列")

        if title and text == title:
            seen_roles.add("title")
            size = paragraph.runs[0].font.size.pt if paragraph.runs and paragraph.runs[0].font.size else None
            font = _east_asian(paragraph.runs[0]) if paragraph.runs else None
            if size != 22.0:
                report.error("D008", f"标题字号应为 2 号（22pt），实际为 {size}pt")
            if font and "小标宋" not in font and font != "华文中宋":
                report.warn("D009", f"标题字体应为小标宋体，实际为“{font}”")
            if str(paragraph.alignment) != "CENTER (1)":
                report.warn("D010", "标题应居中排布")
        elif recipient and text == recipient:
            seen_roles.add("recipient")
            if ind is not None and (ind.get(qn("w:firstLineChars")) or ind.get(qn("w:leftChars"))):
                report.warn("D011", "主送机关应居左顶格，不应有首行缩进")
        elif copy_to and text.startswith("抄送："):
            seen_roles.add("copy_to")
            size = paragraph.runs[0].font.size.pt if paragraph.runs and paragraph.runs[0].font.size else None
            if size != 14.0:
                report.error("D012", f"抄送机关应为 4 号（14pt），实际为 {size}pt")
        elif text and text not in {str(spec.get("signature") or ""), str(spec.get("date") or ""),
                                   str(spec.get("note") or "")}:
            first_line_chars = ind.get(qn("w:firstLineChars")) if ind is not None else None
            if first_line_chars and int(first_line_chars) > 0:
                body_fonts.add(_east_asian(paragraph.runs[0]) if paragraph.runs else "")
                if int(first_line_chars) != 200:
                    report.warn("D013", f"正文段落“{text[:12]}”首行缩进 "
                                        f"{int(first_line_chars) / 100}字，应为 2 字")

    if title and "title" not in seen_roles:
        report.warn("D014", "在文档中未找到与要素文件一致的标题文本")
    if recipient and "recipient" not in seen_roles:
        report.warn("D015", "在文档中未找到与要素文件一致的主送机关文本")

    # 页码域（信函格式默认首页不显示页码）
    expect_page_number = spec.get("page_number", spec.get("format") != "letter")
    if expect_page_number:
        found = False
        for sect in document.sections:
            for footer in (sect.footer, sect.even_page_footer):
                try:
                    xml = footer._element.xml
                except Exception:  # noqa: BLE001
                    continue
                if "PAGE" in xml:
                    found = True
        if not found:
            report.error("D016", "未找到页码域（PAGE）")

    report.info("D017", f"文档共 {len(document.paragraphs)} 个段落，"
                        f"{len(document.tables)} 个表格，{len(document.sections)} 节")

    # 几何层：直接从 OOXML 量尺寸（版心、天头、发文机关标志位置、行网格、页码）
    geometry_report = DocxGeometryReport()
    geometry = check_docx_geometry(path, geometry_report,
                                        str(spec.get("format") or ""))
    for item in geometry_report.items:
        report.items.append(item)
    report.items.append({"level": "info", "code": "D019",
                         "message": "版式几何量：" + json.dumps(geometry, ensure_ascii=False)})


def _east_asian(run) -> str:
    from docx.oxml.ns import qn
    rpr = run._element.find(qn("w:rPr"))
    rfonts = rpr.find(qn("w:rFonts")) if rpr is not None else None
    return rfonts.get(qn("w:eastAsia")) if rfonts is not None else ""


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def main_validate(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):        # Windows 控制台可能是 GBK
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    parser = argparse.ArgumentParser(description="党政公文合规校验器")
    parser.add_argument("spec", help="公文要素 JSON 文件")
    parser.add_argument("--docx", help="同时校验生成的 DOCX 版式")
    parser.add_argument("--json", action="store_true", help="以 JSON 输出报告")
    parser.add_argument("--strict", action="store_true", help="把 warning 也视为失败")
    args = parser.parse_args(argv)

    with open(args.spec, "r", encoding="utf-8-sig") as handle:   # 兼容带 BOM 的 JSON
        spec = json.load(handle)

    report = DocxGeometryReport()
    try:
        validate_spec(spec, report)
    except SpecError as error:
        report.error("S001", str(error))
    if args.docx:
        validate_docx_layer(args.docx, spec, report)

    if args.json:
        print(json.dumps({"spec": args.spec, "docx": args.docx, "items": report.items},
                         ensure_ascii=False, indent=2))
    else:
        print(f"校验对象：{args.spec}" + (f"  +  {args.docx}" if args.docx else ""))
        print(report.render())

    failed = bool(report.errors) or (args.strict and bool(report.warnings))
    return 1 if failed else 0


# --------------------------------------------------------------------------
# 版式几何核对（原 scripts/py，功能不变）
#   DocxGeometryReport / check_docx_geometry —— 不渲染即量出毫米尺寸
# --------------------------------------------------------------------------
TOL_MM = 0.6


RED_HEX = "ff0000"


ALLOWED_FONTS = {
    "仿宋_gb2312", "仿宋", "fangsong", "fangsong_gb2312", "stfangsong",
    "黑体", "simhei", "楷体_gb2312", "楷体", "kaiti", "kaiti_gb2312", "stkaiti",
    "方正小标宋_gbk", "方正小标宋简体", "fzxiaobiaosong-b05s", "华文中宋", "stzhongsong",
    "宋体", "simsun", "nsimsun", "新宋体",
}


class DocxGeometryReport:
    def __init__(self) -> None:
        self.items: list[dict[str, str]] = []

    def add(self, level: str, code: str, message: str) -> None:
        self.items.append({"level": level, "code": code, "message": message})

    def error(self, code: str, message: str) -> None:
        self.add("error", code, message)

    def warn(self, code: str, message: str) -> None:
        self.add("warning", code, message)

    def info(self, code: str, message: str) -> None:
        self.add("info", code, message)

    @property
    def errors(self) -> list[dict[str, str]]:
        return [i for i in self.items if i["level"] == "error"]

    def render(self) -> str:
        icon = {"error": "[错误]", "warning": "[提醒]", "info": "[提示]"}
        lines = [f"{icon[i['level']]} [{i['code']}] {i['message']}" for i in self.items]
        lines.append(f"\n合计：{len(self.errors)} 个错误，"
                     f"{len([i for i in self.items if i['level'] == 'warning'])} 个提醒")
        return "\n".join(lines)


def _near(actual: float, expected: float, tol: float = TOL_MM) -> bool:
    return abs(actual - expected) <= tol


def _paragraphs_with_roles(document):
    """返回 ([(role, paragraph)], [发文机关标志段落], [版头红线段落])。

    角色判断只看段落自身的版式特征（边框颜色、字体颜色字号、位置），
    不依赖生成器写下的任何标注，避免“同源同错”。
    """
    roles = []
    marks = []
    rules = []
    for index, paragraph in enumerate(document.paragraphs):
        text = paragraph.text.strip()
        ppr = paragraph._p.find(qn("w:pPr"))
        borders = ppr.find(qn("w:pBdr")) if ppr is not None else None
        run = paragraph.runs[0] if paragraph.runs else None
        size = run.font.size.pt if run is not None and run.font.size else None
        color = None
        if run is not None and run.font.color is not None and run.font.color.rgb:
            color = str(run.font.color.rgb).lower()
        role = "其他"
        if borders is not None and borders.find(qn("w:bottom")) is not None:
            bottom = borders.find(qn("w:bottom"))
            if (bottom.get(qn("w:color")) or "").lower() == RED_HEX:
                role = "红色分隔线"
                rules.append(paragraph)
            else:
                role = "版记分隔线"
        elif text and color == RED_HEX and size and size >= 20:
            role = "发文机关标志"
            marks.append(paragraph)
        elif not text:
            role = "空行"
        elif size and size >= 20:
            role = "标题（2 号）"
        elif index <= 3 and len(text) <= 12 and not text.endswith(("。", "：")):
            role = "版头要素（份号/密级/紧急程度）"
        roles.append((role, paragraph))
    return roles, marks, rules


def check_docx_geometry(path: str, report: DocxGeometryReport, fmt_hint: str = "") -> dict[str, Any]:
    document = Document(path)
    section = document.sections[0]

    def mm(value) -> float | None:
        return None if value is None else value.mm

    geometry: dict[str, Any] = {"source": path}

    # ---------------- 5.2.1 页面与版心 ----------------
    page = {"width": mm(section.page_width), "height": mm(section.page_height)}
    margins = {"top": mm(section.top_margin), "left": mm(section.left_margin),
               "right": mm(section.right_margin), "bottom": mm(section.bottom_margin)}
    content = {"width": None, "height": None}
    if page["width"] and margins["left"] is not None and margins["right"] is not None:
        content["width"] = round(page["width"] - margins["left"] - margins["right"], 3)
    if page["height"] and margins["top"] is not None and margins["bottom"] is not None:
        content["height"] = round(page["height"] - margins["top"] - margins["bottom"], 3)
    geometry.update({"page_mm": page, "margins_mm": margins, "content_mm": content})

    fmt = fmt_hint or ("letter" if margins["top"] and _near(margins["top"], 30.0) else "standard")
    expected_top = 30.0 if fmt == "letter" else 37.0

    if not (page["width"] and _near(page["width"], PAGE_W_MM, 0.2)):
        report.error("G001", f"页面宽 {page['width']}mm，应为 A4 210mm")
    if not (page["height"] and _near(page["height"], PAGE_H_MM, 0.2)):
        report.error("G002", f"页面高 {page['height']}mm，应为 A4 297mm")
    if not (margins["top"] is not None and _near(margins["top"], expected_top)):
        report.error("G003", f"天头 {margins['top']}mm，应为 {expected_top}mm（5.2.1）")
    if not (margins["left"] is not None and _near(margins["left"], MARGIN_LEFT_MM)):
        report.error("G004", f"订口 {margins['left']}mm，应为 28mm（5.2.1）")
    if content["width"] is not None and not _near(content["width"], CONTENT_W_MM):
        report.error("G005", f"版心宽 {content['width']}mm，应为 156mm（5.2.1）")
    if content["height"] is not None and not _near(content["height"], CONTENT_H_MM):
        report.error("G006", f"版心高 {content['height']}mm，应为 225mm（5.2.1）")

    # ---------------- 5.2.3 行网格 ----------------
    grid = section._sectPr.find(qn("w:docGrid"))
    if grid is None:
        report.warn("G007", "未设置 w:docGrid，Word 中每页行数可能偏离 22 行")
    else:
        pitch = int(grid.get(qn("w:linePitch")) or 0) / 20.0
        geometry["doc_grid_pt"] = round(pitch, 3)
        if pitch and not _near(pitch, LINE_PT, 0.6):
            report.warn("G008", f"文档网格行距 {pitch:.2f}pt，与 22 行/页的 "
                                f"{LINE_PT:.2f}pt 不一致")

    # ---------------- 7.2.4 发文机关标志上边缘 ----------------
    roles, mark_paragraphs, rule_paragraphs = _paragraphs_with_roles(document)
    if mark_paragraphs:
        paragraph = mark_paragraphs[0]
        ppr = paragraph._p.find(qn("w:pPr"))
        spacing = ppr.find(qn("w:spacing")) if ppr is not None else None
        space_before_pt = int(spacing.get(qn("w:before")) or 0) / 20.0 if spacing is not None else 0.0
        # 段落自身的缩进会影响行首位置，但垂直方向只看段前距与行高
        run = paragraph.runs[0] if paragraph.runs else None
        size_pt = run.font.size.pt if run is not None and run.font.size else None
        size_pt = size_pt or 22.0
        # 前导行（份号/密级/紧急程度）各占一行，用版心固定行距 ≈28.99pt 计
        before_lines = 0
        for role, other in roles:
            if other is paragraph:
                break
            if role.startswith("版头要素"):
                before_lines += 1
        # 行高：优先读本段显式固定行距；否则按字体自然度量的典型值估（1.3 倍字号）
        line_pt = None
        if spacing is not None:
            line = spacing.get(qn("w:line"))
            rule = spacing.get(qn("w:lineRule"))
            if line and rule == "exact":
                line_pt = int(line) / 20.0
        line_height = line_pt or max(size_pt * 1.3, LINE_PT)
        glyph_inset = max(0.0, (line_height - size_pt) / 2.0)
        top_from_content = (before_lines * LINE_PT + space_before_pt
                            + glyph_inset) / MM2PT
        expected_offset = 0.0 if fmt == "letter" else (
            20.0 if fmt == "command" else 35.0)
        geometry["issuer_mark"] = {
            "text": paragraph.text.strip(), "size_pt": size_pt,
            "space_before_pt": round(space_before_pt, 3),
            "line_pt": line_pt, "line_height_pt": round(line_height, 3),
            "before_lines": before_lines,
            "top_from_content_mm": round(top_from_content, 3),
            "top_from_page_mm": round((margins["top"] or 0.0) + top_from_content, 3),
            "expected_offset_mm": expected_offset,
        }
        if fmt != "letter":
            if space_before_pt <= 0 and expected_offset > 0:
                report.error("G009", "发文机关标志段前距为 0，标志顶到了版心上边缘，"
                                     f"不符合 7.2.4（应为版心上边缘下 {expected_offset}mm）")
            elif not (expected_offset - 8.0 <= top_from_content <= expected_offset + 8.0):
                report.error("G010", f"发文机关标志上边缘距版心上边缘约 "
                                     f"{top_from_content:.1f}mm，应约为 {expected_offset}mm（7.2.4）")
            else:
                report.info("G011", f"发文机关标志上边缘距版心上边缘约 "
                                    f"{top_from_content:.1f}mm（7.2.4 规定 {expected_offset}mm）")
        else:
            report.info("G011", f"信函格式：发文机关标志上边缘距上页边约 "
                                f"{(margins['top'] or 0) + top_from_content:.1f}mm（10.1 规定 30mm）")
    else:
        report.info("G012", "未在文档中找到红色发文机关标志（公告、通告等无版头文种正常）")

    # ---------------- 7.2.7 红色分隔线 ----------------
    rule_paragraph = rule_paragraphs[0] if rule_paragraphs else None
    if rule_paragraph is not None:
        ppr = rule_paragraph._p.find(qn("w:pPr"))
        ind = ppr.find(qn("w:ind")) if ppr is not None else None
        left_twips = int(ind.get(qn("w:left")) or 0) if ind is not None else 0
        right_twips = int(ind.get(qn("w:right")) or 0) if ind is not None else 0
        width_mm = (CONTENT_W_MM - (left_twips + right_twips) / 20.0 / MM2PT)
        geometry["header_rule"] = {"width_mm": round(width_mm, 3)}
        if not _near(width_mm, CONTENT_W_MM, 1.0):
            report.warn("G013", f"版头红色分隔线长约 {width_mm:.1f}mm，"
                                f"应与版心等宽 156mm（7.2.7）")

    # ---------------- 7.3.3 正文字体字号与缩进 ----------------
    body_fonts: set[str] = set()
    body_sizes: set[float] = set()
    title_ok = False
    for role, paragraph in roles:
        text = paragraph.text.strip()
        if not text or role in {"发文机关标志", "红色分隔线", "版记分隔线"}:
            continue
        run = paragraph.runs[0] if paragraph.runs else None
        rpr = run._element.find(qn("w:rPr")) if run is not None else None
        rfonts = rpr.find(qn("w:rFonts")) if rpr is not None else None
        font = rfonts.get(qn("w:eastAsia")) if rfonts is not None else None
        size = run.font.size.pt if run is not None and run.font.size else None
        if font:
            body_fonts.add(font)
            if font.lower() not in ALLOWED_FONTS:
                report.warn("G014", f"“{text[:12]}…”使用非公文字体“{font}”")
        if size:
            body_sizes.add(size)
        if size == 22.0 and str(paragraph.alignment).startswith("CENTER"):
            title_ok = True
        ppr = paragraph._p.find(qn("w:pPr"))
        spacing = ppr.find(qn("w:spacing")) if ppr is not None else None
        if spacing is not None:
            line = spacing.get(qn("w:line"))
            rule = spacing.get(qn("w:lineRule"))
            if line and rule == "exact":
                line_pt = int(line) / 20.0
                if role == "正文" and not _near(line_pt, LINE_PT, 0.7):
                    report.warn("G015", f"段落“{text[:10]}…”固定行距 {line_pt:.2f}pt，"
                                        f"应为 22 行/页所需的 {LINE_PT:.2f}pt")
    geometry["fonts"] = sorted(body_fonts)
    geometry["sizes_pt"] = sorted(body_sizes)
    if not title_ok:
        report.warn("G016", "未找到 2 号（22pt）居中标题，请确认标题要素（7.3.1）")

    # ---------------- 7.5 页码 ----------------
    page_field = False
    odd_right, even_left = False, False
    for sect in document.sections:
        for footer, is_odd in ((sect.footer, True), (sect.even_page_footer, False)):
            try:
                xml = footer._element.xml
            except Exception:  # noqa: BLE001
                continue
            if "PAGE" in xml:
                page_field = True
                for paragraph in footer.paragraphs:
                    alignment = str(paragraph.alignment)
                    if is_odd and alignment.startswith("RIGHT"):
                        odd_right = True
                    if not is_odd and alignment.startswith("LEFT"):
                        even_left = True
    geometry["page_number"] = {"field": page_field, "odd_right": odd_right,
                              "even_left": even_left}
    if not page_field:
        report.warn("G017", "未找到页码域（7.5）；如为信函格式或未要求页码可忽略")
    elif not (odd_right and even_left):
        report.warn("G018", "页码未同时满足“单页码居右空一字、双页码居左空一字”（7.5）")

    return geometry


def main_geometry(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    parser = argparse.ArgumentParser(description="DOCX 公文版式几何核对（GB/T 9704—2012）")
    parser.add_argument("docx", help="待核对的 DOCX 文件")
    parser.add_argument("--format", dest="fmt", default="standard",
                        choices=["standard", "letter", "command", "minutes", "no_header"],
                        help="版式，默认 standard（决定红头目标位置：35/30/20mm）")
    parser.add_argument("--json", action="store_true", help="以 JSON 输出")
    args = parser.parse_args(argv)

    report = DocxGeometryReport()
    geometry = check_docx_geometry(args.docx, report, args.fmt)

    if args.json:
        print(json.dumps({"geometry": geometry, "items": report.items},
                         ensure_ascii=False, indent=2))
    else:
        print(f"版式核对：{args.docx}")
        print(report.render())
        print("\n几何量：" + json.dumps(geometry, ensure_ascii=False, indent=2))
    return 1 if report.errors else 0


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def main_generate(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):        # Windows 控制台可能是 GBK
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    parser = argparse.ArgumentParser(description="党政机关公文生成器（GB/T 9704—2012）")
    parser.add_argument("spec", nargs="?", help="公文要素 JSON 文件")
    parser.add_argument("-o", "--output", help="输出 DOCX 路径")
    parser.add_argument("--plan", help="同时输出段落规划 JSON")
    parser.add_argument("--fonts", action="store_true", help="打印字体检测结果后退出")
    parser.add_argument("--list-types", action="store_true", help="列出文种与结语后退出")
    parser.add_argument("--font-mode", choices=["auto", "standard"], default="auto",
                        help="auto=缺失时回退；standard=始终写标准字体名")
    parser.add_argument("--font-map", default="", help="覆盖字体角色，如 标题=方正小标宋_GBK,仿宋=仿宋")
    parser.add_argument("--mark-position", choices=["glyph", "data_box"], default=None,
                        help="发文机关标志上边缘的判定基准（默认 glyph：字面上边缘；"
                             "data_box：所在行上边缘）")
    parser.add_argument("--check", action="store_true",
                        help="生成后做版式几何自检，未通过时退出码 1")
    parser.add_argument("--output-format", dest="output_format",
                        choices=["word", "pdf", "both"],
                        help="交付格式（必选，生成前必须问清用户）：word=只要 .docx；"
                             "pdf=只要 .pdf；both=.docx 与 .pdf 两份")
    parser.add_argument("--pdf", dest="pdf", action="store_true", default=None,
                        help=argparse.SUPPRESS)          # 旧写法，等同 --output-format both
    parser.add_argument("--no-pdf", dest="pdf", action="store_false",
                        help=argparse.SUPPRESS)          # 旧写法，等同 --output-format word
    parser.add_argument("--soffice", default="",
                        help="系统 LibreOffice(soffice) 路径；仅与 --allow-system-soffice 一起生效")
    parser.add_argument("--allow-system-soffice", action="store_true",
                        help="允许回退到系统安装的 LibreOffice（默认只用打包的 Kit）")
    parser.add_argument("--ask", action="store_true",
                        help="打印一次问全的要素清单（必答缺项 + 可选项提示）后退出")
    parser.add_argument("--needs", action="store_true", help="只列出还缺的必答要素后退出")
    parser.add_argument("--validate", metavar="DOCX",
                        help="校验要素 JSON 与已生成的 DOCX（要素层 + 版式层 + 几何层）后退出")
    parser.add_argument("--geometry", metavar="DOCX",
                        help="只做版式几何核对（不渲染）后退出")
    parser.add_argument("--strict", action="store_true",
                        help="配合 --validate：把提醒也视为失败")
    parser.add_argument("--type", dest="doc_type", help="配合 --ask / --needs 指定文种")
    parser.add_argument("--node", default="", help="打包 LibreOffice Kit 的 node.exe 路径")
    parser.add_argument("--libreoffice-cli", dest="libreoffice_cli", default="",
                        help="打包 LibreOffice Kit 的 cli.js 路径")
    parser.add_argument("--quiet", action="store_true",
                        help="只打印交付文件路径（默认打印完整生成报告 JSON）")
    args = parser.parse_args(argv)

    if args.node:
        os.environ["DSH_NODE"] = args.node
    if args.libreoffice_cli:
        os.environ["DSH_LIBREOFFICE_CLI"] = args.libreoffice_cli
    if args.soffice:
        os.environ["OFFICIAL_DOC_SOFFICE"] = args.soffice

    if args.fonts:
        installed = detect_installed_fonts()
        resolver = FontResolver(installed, mode=args.font_mode)
        print(json.dumps({
            "detected_font_count": len(installed),
            "resolved": resolver.as_dict(),
            "warnings": resolver.warnings,
        }, ensure_ascii=False, indent=2))
        return 0

    if args.list_types:
        for doc_type in DOC_TYPES:
            closings = "、".join(CLOSING_WORDS.get(doc_type, [])) or "（无固定结语）"
            upward = "上行文（需签发人）" if doc_type in UPWARD_TYPES else "下行文/平行文"
            print(f"{doc_type}\t{upward}\t{closings}")
        return 0

    if not args.spec or not args.output:
        parser.error("需要提供 spec.json 与 -o 输出路径")

    overrides = {}
    for pair in filter(None, args.font_map.split(",")):
        if "=" in pair:
            key, value = pair.split("=", 1)
            overrides[key.strip()] = value.strip()
    resolver = FontResolver(mode=args.font_mode, overrides=overrides)
    spec = load_spec(args.spec)
    if args.mark_position:
        spec["mark_position"] = args.mark_position
    try:
        report = generate(spec, args.output, resolver, args.plan, pdf=args.pdf,
                          allow_system_soffice=args.allow_system_soffice,
                          output_format=args.output_format)
    except SpecError as error:
        print(f"！生成失败：{error}", file=sys.stderr)
        return 2

    layout = report.get("layout") or {}
    failed = layout.get("failed") or []
    if failed:
        report["layout_errors"] = failed
    if args.quiet:
        for path in report["deliverables"]:
            print(path)
    else:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    if failed:
        print(f"版式自检未通过：{'、'.join(failed)}", file=sys.stderr)
        if args.check:
            return 1
    return 0


# --------------------------------------------------------------------------
# 命令分发：生成 / 要素清单 / 校验 / 几何核对
# --------------------------------------------------------------------------
def main(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):        # Windows 控制台可能是 GBK
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    argv = list(sys.argv[1:] if argv is None else argv)

    def _value(flag: str) -> str:
        if flag in argv and argv.index(flag) + 1 < len(argv):
            return argv[argv.index(flag) + 1]
        return ""

    spec_file = next((item for item in argv if item.endswith(".json")), "")

    if "--geometry" in argv:
        target = _value("--geometry")
        if not target:
            print("用法：gongwen.py --geometry 已生成的.docx "
                  "[--format standard|letter|command|minutes|no_header]", file=sys.stderr)
            return 2
        # --format 用于告诉几何核对这是哪种版式（不同版式的红头目标位置不同：
        # standard/minutes 35mm、command 20mm、letter 距上页边 30mm、no_header 无红头）
        fmt_hint = _value("--format")
        extra = (["--format", fmt_hint] if fmt_hint else []) + \
                (["--json"] if "--json" in argv else [])
        return main_geometry([target] + extra)

    if "--validate" in argv:
        target = _value("--validate")
        if not target or not spec_file:
            print("用法：gongwen.py 要素.json --validate 已生成的.docx", file=sys.stderr)
            return 2
        extra = (["--strict"] if "--strict" in argv else []) + \
                (["--json"] if "--json" in argv else [])
        return main_validate([spec_file, "--docx", target] + extra)

    if "--needs" in argv or "--ask" in argv:
        partial: dict = {}
        if spec_file:
            partial.update(load_spec(spec_file))
        if _value("--type"):
            partial["doc_type"] = _value("--type")
        if "--ask" in argv:
            print(json.dumps(ask_checklist(partial), ensure_ascii=False, indent=2))
            return 0
        missing = missing_required(partial)
        print(json.dumps({
            "doc_type": partial.get("doc_type") or "",
            "missing_required": missing,
            "missing_labels": [FIELD_LABELS.get(f, f) for f in missing],
        }, ensure_ascii=False, indent=2))
        return 0

    return main_generate(argv)


if __name__ == "__main__":
    raise SystemExit(main())
