#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""技能维护脚本（不参与公文生成）：语法自检 + 打包 + 发布。

用法::

    python dev.py --syntax      # ast 自检技能内全部 .py
    python dev.py --package     # 重新打 dist/official-doc-writer-<版本>.zip
    python dev.py --publish     # 把 zip 与展示指南复制到桌面
    python dev.py --all         # 依次执行以上三步
"""

from __future__ import annotations

import argparse
import ast
import os
import re
import shutil
import sys
import zipfile
from typing import Sequence

SKILL_ROOT = os.path.dirname(os.path.abspath(__file__))   # dev.py 就在技能根目录下
SKILL_SCRIPTS_ROOT = os.path.join(SKILL_ROOT, "scripts")
SKILL_SCRIPTS = SKILL_SCRIPTS_ROOT

SKILL_NAME = "official-doc-writer"


# 打进包里的顶层条目（不存在的自动跳过）
INCLUDE = ["SKILL.md", "README.md", "LICENSE", "dev.py", "如何运行与展示.md",
           "fonts", "references", "scripts", "examples"]


# 始终排除的内容
EXCLUDE_DIRS = {"__pycache__", "dist", ".git", ".idea", ".vscode", "_probe"}


EXCLUDE_FILES = {".DS_Store", "Thumbs.db"}


EXCLUDE_SUFFIX = (".pyc", ".pyo")


# --no-examples 时排除的目录
EXAMPLE_HEAVY = {"examples/generated"}


def skill_version() -> str:
    path = os.path.join(SKILL_ROOT, "SKILL.md")
    try:
        with open(path, "r", encoding="utf-8") as handle:
            match = re.search(r"^version:\s*[\"']?([\w.\-]+)", handle.read(), re.M)
        if match:
            return match.group(1)
    except OSError:
        pass
    return "1.0.0"


def iter_files(base: str, *, with_examples: bool):
    """产出 (绝对路径, 包内相对路径)。"""
    for entry in INCLUDE:
        source = os.path.join(SKILL_ROOT, entry)
        if not os.path.exists(source):
            continue
        if os.path.isfile(source):
            yield source, entry
            continue
        for root, dirs, files in os.walk(source):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            relative_root = os.path.relpath(root, SKILL_ROOT).replace("\\", "/")
            if not with_examples and relative_root in EXAMPLE_HEAVY:
                continue
            for filename in sorted(files):
                if filename in EXCLUDE_FILES or filename.endswith(EXCLUDE_SUFFIX):
                    continue
                absolute = os.path.join(root, filename)
                relative = os.path.relpath(absolute, SKILL_ROOT).replace("\\", "/")
                yield absolute, relative


def package(output: str, *, with_examples: bool = True, verbose: bool = True) -> str:
    os.makedirs(os.path.dirname(os.path.abspath(output)) or ".", exist_ok=True)
    count = 0
    total = 0
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for absolute, relative in iter_files(SKILL_ROOT, with_examples=with_examples):
            archive.write(absolute, f"{SKILL_NAME}/{relative}")     # 顶层目录 = 技能名
            count += 1
            total += os.path.getsize(absolute)
    if verbose:
        size = os.path.getsize(output)
        print(f"已打包 {count} 个文件（原始 {total / 1024:.0f} KB → 压缩后 {size / 1024:.0f} KB）")
        print(f"包内顶层目录：{SKILL_NAME}/")
        print(f"输出：{os.path.abspath(output)}")
    return os.path.abspath(output)


def verify(zip_path: str) -> list[str]:
    """自检：SKILL.md 必须在顶层目录内，且 frontmatter 的 name 与目录名一致。"""
    problems: list[str] = []
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
        skill_md = f"{SKILL_NAME}/SKILL.md"
        if skill_md not in names:
            problems.append(f"包内缺少 {skill_md}（技能将无法被发现）")
        else:
            text = archive.read(skill_md).decode("utf-8")
            match = re.search(r"^name:\s*[\"']?([\w.\-]+)", text, re.M)
            if not match:
                problems.append("SKILL.md frontmatter 缺少 name")
            elif match.group(1) != SKILL_NAME:
                problems.append(f"frontmatter name={match.group(1)} 与顶层目录名 {SKILL_NAME} 不一致")
            if not re.search(r"^description:\s*\S", text, re.M):
                problems.append("SKILL.md frontmatter 缺少 description")
        nested = [n for n in names if n.count("/") >= 2 and n.endswith("SKILL.md")]
        if nested:
            problems.append(f"存在嵌套的 SKILL.md（不会被发现）：{nested}")
    return problems


def main_package(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    version = skill_version()
    parser = argparse.ArgumentParser(description="打包 official-doc-writer 技能")
    parser.add_argument("--version", default=version, help=f"版本号（默认 {version}）")
    parser.add_argument("--out", default=os.path.join(SKILL_ROOT, "dist"), help="输出目录（默认 dist/）")
    parser.add_argument("--no-examples", action="store_true", help="不含生成的 docx 与预览图（更小）")
    args = parser.parse_args(argv)

    output = os.path.join(args.out, f"{SKILL_NAME}-{args.version}.zip")
    zip_path = package(output, with_examples=not args.no_examples)
    problems = verify(zip_path)
    if problems:
        print("\n！打包自检未通过：")
        for problem in problems:
            print(f"  - {problem}")
        return 1
    print("\n打包自检通过：顶层 official-doc-writer/SKILL.md 存在，name/description 合法，无嵌套 SKILL.md。")
    print("\n安装（任选其一）：")
    print(f"  1) DSH 用户级：解压后把 official-doc-writer 整个目录放到 ~/.dsh/skills/")
    print(f"  2) DSH 项目级：放到 <项目根>/.dsh/skills/ 或 <项目根>/.agents/skills/")
    print(f"  3) 其他环境：把 official-doc-writer 放到该环境的 skills 目录")
    return 0


SKIP_DIRS = {"__pycache__", ".git", "dist", "build", ".venv", "venv", "node_modules"}


def iter_python_files(root: str):
    if os.path.isfile(root):
        if root.endswith(".py"):
            yield root
        return
    for directory, subdirs, files in os.walk(root):
        subdirs[:] = [d for d in subdirs if d not in SKIP_DIRS]
        for name in sorted(files):
            if name.endswith(".py"):
                yield os.path.join(directory, name)


def check(path: str) -> tuple[bool, str]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            source = handle.read()
    except OSError as error:
        return False, f"无法读取：{error}"
    try:
        ast.parse(source, filename=path)
    except SyntaxError as error:
        return False, (f"语法错误：第 {error.lineno} 行第 {error.offset} 列："
                       f"{error.msg}")
    return True, ""


def main_syntax(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            pass
    parser = argparse.ArgumentParser(description="技能内 Python 文件语法自检")
    parser.add_argument("paths", nargs="*", help="文件或目录，默认本目录与技能根目录")
    args = parser.parse_args(argv)

    here = os.path.dirname(os.path.abspath(__file__))
    roots = args.paths or [here]
    # 只扫技能自身：跳过下载的第三方技能与备份，避免扫描整盘
    SKIP_DIRS.update({"downloads", "_pre_compress_backup", "dist", "out"})

    failed = 0
    checked = 0
    seen: set[str] = set()
    for root in roots:
        for path in iter_python_files(root):
            real = os.path.realpath(path)
            if real in seen:
                continue
            seen.add(real)
            checked += 1
            ok, message = check(path)
            if ok:
                print(f"[ok]   {os.path.relpath(path, os.path.dirname(here))}")
            else:
                failed += 1
                print(f"[fail] {os.path.relpath(path, os.path.dirname(here))}: {message}")
    print(f"\n共检查 {checked} 个文件，{failed} 个有语法错误")
    return 1 if failed else 0


DESKTOP = r"D:\Users\Administrator\Desktop"


ZIP_NAME = f"official-doc-writer-{skill_version()}.zip"


def main_publish(argv: Sequence[str] | None = None) -> int:
    """把打包好的 zip 与展示指南复制到桌面，便于分发。"""
    source_zip = os.path.join(SKILL_ROOT, "dist", ZIP_NAME)
    target_zip = os.path.join(DESKTOP, ZIP_NAME)
    if not os.path.isfile(source_zip):
        print(f"！找不到打包结果：{source_zip}（先运行 dev.py --package）")
        return 1
    shutil.copy2(source_zip, target_zip)
    print(f"zip：{target_zip}  {os.path.getsize(target_zip)} bytes")
    guide_source = os.path.join(SKILL_ROOT, "如何运行与展示.md")
    if os.path.isfile(guide_source):
        guide_target = os.path.join(DESKTOP, "如何运行与展示-official-doc-writer.md")
        shutil.copy2(guide_source, guide_target)
        print(f"指南：{guide_target}  {os.path.getsize(guide_target)} bytes")
    with zipfile.ZipFile(target_zip) as archive:
        broken = archive.testzip()
        print("zip 完整性：", "ok" if broken is None else f"损坏于 {broken}")
        print("包内文件数：", len(archive.namelist()))
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="技能维护脚本")
    parser.add_argument("--syntax", action="store_true", help="语法自检")
    parser.add_argument("--package", action="store_true", help="重新打包")
    parser.add_argument("--publish", action="store_true", help="发布到桌面")
    parser.add_argument("--all", action="store_true", help="依次三步")
    args = parser.parse_args(argv)
    steps = []
    if args.syntax or args.all:
        steps.append(main_syntax)
    if args.package or args.all:
        steps.append(main_package)
    if args.publish or args.all:
        steps.append(main_publish)
    if not steps:
        parser.print_help()
        return 0
    for step in steps:
        code = step([])
        if code:
            return code
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
