# 贡献指南

感谢你愿意改进这个项目。为了不把"格式合规"这个核心卖点改坏，改动请遵循下面的流程。

## 一、先跑通，再改

```bash
git clone https://github.com/<你的用户名>/official-doc-writer.git
cd official-doc-writer
pip install python-docx

# 1) 环境检查
python dev.py --syntax
python scripts/gongwen.py --fonts

# 2) 生成一份看看
python scripts/gongwen.py examples/01-通知.json -o 通知.docx --output-format both --check

# 3) 量尺寸，确认没坏
python scripts/gongwen.py --geometry 通知.docx
```

## 二、改动后必须做的四步自检

```bash
python dev.py --syntax                                                          # 1. 语法
python scripts/gongwen.py examples/01-通知.json -o t.docx --output-format word --check   # 2. 版式自检
python scripts/gongwen.py examples/01-通知.json --validate t.docx               # 3. 要素+版式+几何 0 错误
# 4. 16 份样例全跑一遍（见下），确认没有文种回归
```

```powershell
# Windows PowerShell：一次跑完 16 份样例
New-Item -ItemType Directory -Force out | Out-Null
Get-ChildItem examples\*.json | ForEach-Object {
  python scripts/gongwen.py $_.FullName -o ("out\" + $_.BaseName + ".docx") --output-format both --check --quiet
}
```

推 PR 后 GitHub Actions 会再自动量一遍红头位置、版心、行距，超差会直接 fail。

## 三、改哪里（定位指引）

| 想改什么 | 改哪个文件 | 关键符号 |
| --- | --- | --- |
| 红头位置（默认 35mm） | `scripts/gongwen.py` | `MARK_OFFSET_MM`、`mark_placement()` |
| 字号、行距、页边距 | `scripts/gongwen.py` | 文件顶部的常量区（`SIZE_2/3/4`、`LINE_PT`、`MARGIN_*`） |
| 某个要素怎么排 | `scripts/gongwen.py` | `GongwenBuilder.build_header/build_body/build_version_record` |
| 校验规则 | `scripts/gongwen.py` | `validate_spec()`、`validate_docx_layer()` |
| 几何核对项 | `scripts/gongwen.py` | `check_docx_geometry()` |
| 必答/可选项清单 | `scripts/gongwen.py` | `BASE_REQUIRED`、`REQUIRED_ASKS`、`OPTIONAL_ASKS` |
| 写作提示（开头语/结构骨架） | `scripts/prompts.py` | `OPENING_PROMPTS`、`STRUCTURE_HINTS` |
| 打包/发布规则 | `dev.py` | `INCLUDE`、`package()` |

## 四、两条硬约束

1. **不要降低"可验证"能力**：任何影响排版的改动，都要能让 `--check` / `--geometry` 量出来。新增格式要求时，最好同时在 `check_docx_geometry()` 里加一条断言。
2. **不要破坏"先问后写"**：必答项缺失时必须**零文件产出**（退出码 2）。不要为了方便绕过这道闸。

## 五、提交信息与 PR

- 提交信息用中文或英文都可以，写清"改了什么、为什么"，例如：
  `fix(版头): 红头段前距改按字体真实行高计算，修正整体下沉 38mm`
- PR 描述里请附上自检输出（`--check` 与 `--geometry` 的关键几行）。
- 涉及版式的截图对比（改前/改后 PDF 首页）非常有帮助。

## 六、样例与产物

- `examples/*.json`：16 种文种/版式的样例**输入**，改动字段结构时请同步更新。
- `examples/generated/*.docx` 与 `examples/preview/*.png`：样例**输出**，改了排版后请重新生成并一起提交（用上面第二步的命令）。
- 生成到别处的临时公文、`out/`、`dist/`、`downloads/` 都不入库（见 `.gitignore`）。
